package com.orderSystem.shops.service;

import com.orderSystem.entity.Dish;

/*操作菜品表dish的服务层接口*/
public interface DishService {
	
	Dish findDishById(int id);//根据dishId查询其对应的菜品信息
	
}
