package com.orderSystem.users.action;

import com.orderSystem.users.service.AddressService;
import com.orderSystem.users.service.UserService;
import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.User;

public class UserAction {

	private int userId;
	private String userName;
	private String userPhone;
	private String pwd;
	UserService userService;
	
	private String address;
	AddressService addressService;
	
	
	/*=======action methods========*/
	
//	根据用户userId获取用户对应的账号信息
	public String getUserInfoById() {
		ActionContext ac = ActionContext.getContext();
		User user = userService.findUserById(userId);
		ac.put("userId", userId);
		ac.put("user", user);
		return "show";
	}
//  修改用户表user和地址表address，存在多个地址难以唯一识别的问题，把“地址修改”功能移至“地址管理”选项
//	public String updateUserInfo() {
//		User user = userService.findUserById(userId);
//		Address addr = addressService.findAddressByUserId(userId).get(0);
//		ActionContext ac = ActionContext.getContext();
//		ac.put("user", user);
//		ac.put("addr", addr);
//		return "update";
//	}
	
//	传参，然后跳转
	public String updateUserInfo() {
		User user = userService.findUserById(userId);
		ActionContext ac = ActionContext.getContext();
		ac.put("user", user);
		return "update";
	}
	
//	修改用户表user，其中工号不变，可以修改用户名、手机号和密码
	public String updateUserInfoSuccess(){
		User user = userService.findUserById(userId);
		user.setUserName(userName);
		user.setUserPhone(userPhone);
		user.setPwd(pwd);
		userService.updateUser(user);
		ActionContext ac = ActionContext.getContext();
		ac.put("user", user);
		return "success";
	}	
	
	/*=======getters and setters========*/
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public AddressService getAddressService() {
		return addressService;
	}

	public void setAddressService(AddressService addressService) {
		this.addressService = addressService;
	}


	
}
