package com.orderSystem.order.tool;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.orderSystem.entity.Cart;

/**
 * 工具类，用来从http请求中获取当前提交的cart的id号
 * 操作结果放入到List集合中
 * 便于后面通过id号获取当前提交的订单中所涉及的cart对象
 * @author 855860
 *
 */
public class getCartList {
	public List<Integer> getList(){
		HttpServletRequest request = ServletActionContext.getRequest();
		//获取前端页面中form表单中所有name属性值为“cart.cartId”的值，返回值为一个数组
		String[] values = request.getParameterValues("cart.cartId");
		List<Integer> cartIdList = new ArrayList<Integer>();
		/*Enumeration paramNames = request.getParameterNames();
		while (paramNames.hasMoreElements()){
			String paramName = (String) paramNames.nextElement();
			//所有cart的id取完后退出循环
			if(paramName.equals("cart.cartId"))
				cartIdList.add(Integer.valueOf(request.getParameter(paramName)));
		}*/
		for(int i=0; i<values.length; i++){
			cartIdList.add(Integer.valueOf(values[i]));	
		}
		
		return cartIdList;
	}
}
