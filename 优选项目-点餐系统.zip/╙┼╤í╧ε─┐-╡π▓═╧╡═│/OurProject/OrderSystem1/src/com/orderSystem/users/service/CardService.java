package com.orderSystem.users.service;

import com.orderSystem.entity.Card;

/*操作储值卡表card的服务层接口*/
public interface CardService {
	
	Card findCardById(int id); // 根据储值卡的cardId查询特定的储值卡
	
}
