package com.orderSystem.entity;

/**
 * AbstractCart entity provides the base persistence definition of the Cart
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractCart implements java.io.Serializable {

	// Fields

	private Integer cartId;
	private Integer orderId;
	private Integer shopId;
	private Integer dishId;
	private Integer dishNumber;
	private Long cartPrice;
	private String status;

	// Constructors

	/** default constructor */
	public AbstractCart() {
	}

	/** full constructor */
	public AbstractCart(Integer orderId, Integer shopId, Integer dishId,
			Integer dishNumber, Long cartPrice, String status) {
		this.orderId = orderId;
		this.shopId = shopId;
		this.dishId = dishId;
		this.dishNumber = dishNumber;
		this.cartPrice = cartPrice;
		this.status = status;
	}

	// Property accessors

	public Integer getCartId() {
		return this.cartId;
	}

	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public Integer getDishId() {
		return this.dishId;
	}

	public void setDishId(Integer dishId) {
		this.dishId = dishId;
	}

	public Integer getDishNumber() {
		return this.dishNumber;
	}

	public void setDishNumber(Integer dishNumber) {
		this.dishNumber = dishNumber;
	}

	public Long getCartPrice() {
		return this.cartPrice;
	}

	public void setCartPrice(Long cartPrice) {
		this.cartPrice = cartPrice;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}