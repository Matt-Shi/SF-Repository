package com.orderSystem.administrator;

import java.util.List;

import com.orderSystem.entity.User;

public interface userService {

	public void save(User user);
	public void delete(User user);
	public User findByUserId(int userId);
	public List<User>findAll();
	public void updateUser(User user);
	public List<User> findLikeByName(String name);
	public List<User> findByUserName(String name);
}
