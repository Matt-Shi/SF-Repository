package com.orderSystem.entity;

/**
 * Cart entity. @author MyEclipse Persistence Tools
 */
public class Cart extends AbstractCart implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Cart() {
	}

	/** full constructor */
	public Cart(Integer orderId, Integer shopId, Integer dishId,
			Integer dishNumber, Long cartPrice, String status) {
		super(orderId, shopId, dishId, dishNumber, cartPrice, status);
	}

}
