package com.orderSystem.shops;


import java.util.List;

import org.hibernate.Transaction;

import com.orderSystem.dao.AddressDAO;
import com.orderSystem.dao.CartDAO;
import com.orderSystem.dao.ComplaintDAO;
import com.orderSystem.dao.DishDAO;
import com.orderSystem.dao.DishTypeDAO;
import com.orderSystem.dao.ShopDAO;
import com.orderSystem.dao.ShopOrderDAO;
import com.orderSystem.dao.UserDAO;
import com.orderSystem.entity.Address;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Complaint;
import com.orderSystem.entity.DishType;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.entity.User;

public class ShopServiceImpl implements ShopService{
	ShopDAO shopdao = new ShopDAO();
	ComplaintDAO complaintpdao=new ComplaintDAO();
	DishTypeDAO dishtypedao=new DishTypeDAO();
	@Override
	public List<Shop> getAllShop() {
		Shop shop = new Shop();
		List<Shop> shops = shopdao.findAll();
		return shops;
	}
	@Override
	public Shop getShopById(int id) {
		return shopdao.findById(id);
	}
	@Override
	public String getShopTypeById(int shopId) {
		Shop shop=shopdao.findById(shopId);
		DishType dt=dishtypedao.findById(shop.getTypeId());
		return dt.getTypeName();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<DishType> getAllShopType() {
		
		return (List<DishType>)dishtypedao.findAll();
	}
	@Override
	public int getTypeIdByTypeName(String shopType) {
		List<DishType> dy=(List<DishType>)dishtypedao.findByTypeName(shopType);
		if(dy.size()==1)
		{
			return dy.get(0).getTypeId();
		}
		return 0;
	}
	@Override
	public void updateShop(Shop shop2) {
		Transaction tc=shopdao.getSession().beginTransaction();
		if(shopdao.findById(shop2.getShopId())!=null)
		shopdao.merge(shop2);
		tc.commit();
		shopdao.getSession().close();	
	}
	public List<Complaint> getAllComplaintByShopId(int shopId)
	{
		
		return (List<Complaint>) complaintpdao.findByShopId(shopId);
	}
	public String getUserNameById(int userId)
	{
		UserDAO userdao=new UserDAO();	
		return userdao.findById(userId).getUserName();
	}
	@Override
	public List<Cart> getAllCart(int shopId) {
		CartDAO cartdao=new CartDAO();
		List<Cart> carts=cartdao.findByShopId(shopId);
		return carts;
	}
	@Override
	public String getDishName(int dishId) {
		DishDAO dishdao=new DishDAO();
		return dishdao.findById(dishId).getDishName();
	}
	ShopOrderDAO orderdao=new ShopOrderDAO();
	@Override
	public ShopOrder getOrderById(int orderId) {
		return orderdao.findById(orderId);
	}
	UserDAO userdao=new UserDAO();
	@Override
	public User getUserById(int userId) {
	
		return userdao.findById(userId);
	}
	@Override
	public Address getAddressById(int addressId) {
		AddressDAO addressdao=new AddressDAO();
		return addressdao.findById(addressId);
	}
	@Override
	public void ChangeCartStatus(int cartId) {
		CartDAO cartdao=new CartDAO();
		Cart cart=cartdao.findById(cartId);
		cart.setStatus("已受理");
		
		Transaction tc=cartdao.getSession().beginTransaction();
		cartdao.merge(cart);
		tc.commit();
		cartdao.getSession().close();
	}
	@Override
	public Shop getShopByCode(String shopCode) {
		List<Shop> shops=shopdao.findByShopCode(shopCode);
		if(shops.size()==1)return shops.get(0);
		return null;
	}
	ShopNewDao shopnewdao=new ShopNewDao();
	@Override
	public List<Cart> getCartByLikeUserName(String username, int shopId) {
		
		return (List<Cart>)shopnewdao.findLikeByCartName(username, shopId);
	}
	@Override
	public List<Complaint> getComplaintByLikeUserName(String username,
			int shopId) {
		// TODO Auto-generated method stub
		return (List<Complaint>)shopnewdao.findLikeByComplaintName(username, shopId);
	}

}
