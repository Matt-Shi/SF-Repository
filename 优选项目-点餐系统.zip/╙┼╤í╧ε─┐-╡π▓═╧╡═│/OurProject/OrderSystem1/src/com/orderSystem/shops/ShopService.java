package com.orderSystem.shops;

import java.util.List;

import com.orderSystem.entity.Address;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Complaint;
import com.orderSystem.entity.DishType;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.entity.User;

public interface ShopService {
	List<Shop> getAllShop();
	Shop getShopById(int id);
	String getShopTypeById(int shopId);
	List<DishType> getAllShopType();
	int getTypeIdByTypeName(String shopType);
	void updateShop(Shop shop2);
	public List<Complaint> getAllComplaintByShopId(int shopId);
	public String getUserNameById(int userId);
	public List<Cart> getAllCart(int shopId);
	public String getDishName(int dishId);
	public ShopOrder getOrderById(int orderId);
	public User getUserById(int userId);
	public Address getAddressById(int addressId);
	public void ChangeCartStatus(int cartId);
	public Shop getShopByCode(String shopCode);
	public List<Cart> getCartByLikeUserName(String username,int shopId);
	public List<Complaint> getComplaintByLikeUserName(String username,int shopId);
}
