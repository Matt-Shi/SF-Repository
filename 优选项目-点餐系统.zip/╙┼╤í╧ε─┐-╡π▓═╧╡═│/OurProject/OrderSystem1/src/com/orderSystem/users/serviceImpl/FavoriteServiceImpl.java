package com.orderSystem.users.serviceImpl;

import java.util.List;

import org.hibernate.Transaction;

import com.orderSystem.dao.FavoriteDAO;
import com.orderSystem.entity.Favorite;
import com.orderSystem.users.service.FavoriteService;

/*操作收藏表favorite的服务层接口实现类*/
public class FavoriteServiceImpl implements FavoriteService {

	FavoriteDAO favDao = new FavoriteDAO();

	@Override
	public Favorite findFavoriteById(int id) {
		return favDao.findById(id);
	}

	@Override
	public List<Favorite> findFavoriteByUserId(int userId) {
		return favDao.findByUserId(userId);
	}

	@Override
	public void deleteFavoriteById(int favId) {
		Transaction tr = favDao.getSession().beginTransaction();
		Favorite fav = null;
		if ((fav = favDao.findById(favId)) != null)
			favDao.delete(fav);
		tr.commit();
		favDao.getSession().close();
	}

}
