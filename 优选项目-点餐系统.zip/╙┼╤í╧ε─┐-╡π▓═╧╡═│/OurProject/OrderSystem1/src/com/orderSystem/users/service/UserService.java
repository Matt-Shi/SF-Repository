package com.orderSystem.users.service;

import com.orderSystem.entity.User;

/*操作用户表user的服务层接口*/
public interface UserService {

	User findUserById(int id);// 通过userId查询其对应的用户信息

	boolean updateUser(User user);// 更新用户表user
}
