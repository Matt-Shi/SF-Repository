package com.orderSystem.users.action;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.Address;
import com.orderSystem.entity.User;
import com.orderSystem.users.service.AddressService;
import com.orderSystem.users.service.UserService;

public class AddressAction {
	int addrId;
	int userId;
	String address;
	
	AddressService addrService;
	UserService userService;

	/*=======action methods========*/
	
//	根据userId查询用户对应的地址列表
	public String getAddressByUserId() {
		ActionContext ac = ActionContext.getContext();
		List<Address> addrs = addrService.findAddressByUserId(userId);
		User user = userService.findUserById(userId);
		ac.put("addrs", addrs);
		ac.put("userId", userId);
		ac.put("user", user);
		return "show";
	}
	
//	传参，然后跳转
	public String updateAddress() {
		Address addr = addrService.findAddressById(addrId);
		User user = userService.findUserById(userId);
		ActionContext ac = ActionContext.getContext();
		ac.put("addr", addr);
		ac.put("userId", userId);
		ac.put("user", user);
		return "update";
	}

//	修改地址信息，并更新到数据库address表
	public String updateAddressSuccess() {
		Address addr = addrService.findAddressById(addrId);
		User user = userService.findUserById(userId);
		addr.setDescription(address);
		addrService.updateAddress(addr);// 更新数据库记录
		List<Address> addrs = addrService.findAddressByUserId(userId);
		ActionContext ac = ActionContext.getContext();
		ac.put("addrs", addrs);
		ac.put("userId", userId);
		ac.put("user", user);
		return "success";
	}
	
//	根据addrId删除对应的地址
	public String deleteAddressById() {
		addrService.deleteAddressById(addrId);
		ActionContext ac = ActionContext.getContext();
		List<Address> addrs = addrService.findAddressByUserId(userId);
		User user = userService.findUserById(userId);
		ac.put("addrs", addrs);
		ac.put("userId", userId);
		ac.put("user", user);
		return "delete";
	}

//	传参，然后跳转
	public String addAddress() {
		ActionContext ac = ActionContext.getContext();
		User user = userService.findUserById(userId);
		ac.put("userId", userId);
		ac.put("user", user);
		return "add";
	}

//	添加地址信息，并更新到数据库address表
	public String isAddressAdded() {
		Address addr = new Address();
		addr.setAddrId(Integer.MAX_VALUE);
		addr.setUserId(userId);
		addr.setDescription(address);
		boolean isAdded = addrService.saveAddress(addr);
		List<Address> addrs = addrService.findAddressByUserId(userId);
		ActionContext ac = ActionContext.getContext();
		User user = userService.findUserById(userId);
		ac.put("idAdded", isAdded);
		ac.put("userId", userId);
		ac.put("addrs", addrs);
		ac.put("user", user);
		return "isAddedSuccess";
	}
	
	/*=======getters and setters========*/
	
	public int getAddrId() {
		return addrId;
	}

	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}


	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public AddressService getAddrService() {
		return addrService;
	}

	public UserService getUserService() {
		return userService;
	}
	
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void setAddrService(AddressService addrService) {
		this.addrService = addrService;
	}

}
