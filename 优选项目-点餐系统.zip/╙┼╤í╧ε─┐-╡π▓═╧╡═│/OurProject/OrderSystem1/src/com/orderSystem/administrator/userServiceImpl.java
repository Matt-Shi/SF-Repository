package com.orderSystem.administrator;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.orderSystem.dao.UserDAO;
import com.orderSystem.entity.User;

public class userServiceImpl implements userService {

	private UserDAO userDao;
	public UserDAO getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDAO userDao) {
		this.userDao = userDao;
	}

	@Override
	public void save(User user) {
		// TODO Auto-generated method stub
		Transaction ts = userDao.getSession().beginTransaction();
		userDao.save(user);
		ts.commit();
		userDao.getSession().close();
	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub
		if(userDao.findById(user.getUserId())!=null){
			Transaction ts = userDao.getSession().beginTransaction();
			userDao.delete(user);
			ts.commit();
			userDao.getSession().close();
		}
	}

	@Override
	public User findByUserId(int userId) {
		// TODO Auto-generated method stub
		return userDao.findById(userId);
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userDao.findAll();
	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub
		Transaction ts = userDao.getSession().beginTransaction();
		userDao.merge(user);
		ts.commit();
		userDao.getSession().close();
	}

	@Override
	public List<User> findLikeByName(String name) {
		// TODO Auto-generated method stub
		/*private Integer userId;
		private String userName;
		private Boolean sex;
		private String userPhone;
		private Integer cardId;
		private String role;
		private String pwd;*/
			try{
				int sex=-1;
				if(name.equals("��")){
					sex=1;
				}else if(name.equals("Ů")){
					sex=0;
				}
				name="'%"+name+"%'";
				Query query = userDao.getSession().createQuery("from User where userName like "+name+
						" or role like "+name+" or userPhone like "+name+" or sex = "+ sex);
				List<User>list = query.list();
				return list;
			}catch(RuntimeException ex){
				throw ex;
		}
	}

	@Override
	public List<User> findByUserName(String name) {
		// TODO Auto-generated method stub
		return userDao.findByUserName(name);
	}

}
