package com.orderSystem.shops;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import com.orderSystem.dao.DishDAO;
import com.orderSystem.entity.Dish;

public class DishServiceImpl implements DishService {
	
	DishDAO dishdao=new DishDAO();
	@Override
	public List<Dish> getAllDishByShopId2(int id) {
		return (List<Dish>)dishdao.findByShopId(id);
	}
	@Override
	// ʵ�ֲ�Ʒ���
	public boolean saveDish(Dish Dish) {
		
		try {
			Transaction tr = dishdao.getSession().beginTransaction();
			dishdao.save(Dish);
			tr.commit();
			dishdao.getSession().close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
		
	}

	// ɾ���Ʒ
	public void deleteDishById(int dishId) {
		Transaction tr = dishdao.getSession().beginTransaction();
		Dish dish=null;
		if ((dish=dishdao.findById(dishId))!= null)
			dishdao.delete(dish);
		tr.commit();
		dishdao.getSession().close();
	}

	// ���²�Ʒ
	public boolean updateDish(Dish Dish){
		try{
			Transaction tr = dishdao.getSession().beginTransaction();
			if (dishdao.findById(Dish.getDishId()) != null)
				dishdao.merge(Dish);
			tr.commit();
			dishdao.getSession().close();
			}catch(Exception e)
		{
			return false;
		}
		return true;
	}

	// ����Ʒ���ֲ���
	public List<Dish> getDish(String dishName){
		List<Dish> dishList = dishdao.findByDishName(dishName);
		return dishList;
	}

	// ��ID����
	public Dish findDishById(int Id) {
		return dishdao.findById(Id);		
	}
	// ����ȫ��
	public List<Dish> findAll() {
		return dishdao.findAll();
	}
	ShopNewDao shopnewdao=new ShopNewDao();
	//按照菜名模糊查询按照菜名模糊查询按照菜名模糊查询按照菜名模糊查询按照菜名模糊查询按照菜名模糊查询
		public List<Dish> findByLikeName(String name,int shopId) {
			return shopnewdao.findLikeByDishName( name,shopId);
		}
}
