package com.orderSystem.entity;

/**
 * DishType entity. @author MyEclipse Persistence Tools
 */
public class DishType extends AbstractDishType implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public DishType() {
	}

	/** full constructor */
	public DishType(String typeName) {
		super(typeName);
	}

}
