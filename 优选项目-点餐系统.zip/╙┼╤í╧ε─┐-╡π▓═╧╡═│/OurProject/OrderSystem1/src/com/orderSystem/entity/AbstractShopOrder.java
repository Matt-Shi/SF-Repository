package com.orderSystem.entity;

import java.sql.Timestamp;

/**
 * AbstractShopOrder entity provides the base persistence definition of the
 * ShopOrder entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractShopOrder implements java.io.Serializable {

	// Fields

	private Integer orderId;
	private Integer userId;
	private Timestamp orderTime;
	private Long total;
	private Integer addrId;

	// Constructors

	/** default constructor */
	public AbstractShopOrder() {
	}

	/** full constructor */
	public AbstractShopOrder(Integer userId, Timestamp orderTime, Long total,
			Integer addrId) {
		this.userId = userId;
		this.orderTime = orderTime;
		this.total = total;
		this.addrId = addrId;
	}

	// Property accessors

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Timestamp getOrderTime() {
		return this.orderTime;
	}

	public void setOrderTime(Timestamp orderTime) {
		this.orderTime = orderTime;
	}

	public Long getTotal() {
		return this.total;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public Integer getAddrId() {
		return this.addrId;
	}

	public void setAddrId(Integer addrId) {
		this.addrId = addrId;
	}

}