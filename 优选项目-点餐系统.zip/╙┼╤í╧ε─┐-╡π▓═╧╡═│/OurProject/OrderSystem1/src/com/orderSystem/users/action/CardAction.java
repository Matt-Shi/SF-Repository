package com.orderSystem.users.action;


import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.Card;
import com.orderSystem.entity.User;
import com.orderSystem.users.service.CardService;
import com.orderSystem.users.service.UserService;

public class CardAction {
	
	private int cardId;
	private int userId;
	
	UserService userService;
	CardService cardService;
	
	/*=======action methods========*/
	
//	根据userId查询用户关联的储值卡的余额
	public String getCardInfoByUserId() {
		ActionContext ac = ActionContext.getContext();
		User user = userService.findUserById(userId);
		Card card = cardService.findCardById(user.getCardId());
		ac.put("userId", userId);
		ac.put("user", user);
		ac.put("balance",card.getBalance());
		return "show";
	}
	
	/*=======getters and setters========*/
	
	public int getCardId() {
		return cardId;
	}
	public void setCardId(int cardId) {
		this.cardId = cardId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public UserService getUserService() {
		return userService;
	}
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	public CardService getCardService() {
		return cardService;
	}
	public void setCardService(CardService cardService) {
		this.cardService = cardService;
	}
	
	
	
}
