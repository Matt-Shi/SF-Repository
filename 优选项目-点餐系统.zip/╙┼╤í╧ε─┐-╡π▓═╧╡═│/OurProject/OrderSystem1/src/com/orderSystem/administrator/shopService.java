package com.orderSystem.administrator;

import java.util.List;
import java.util.Map;

import com.orderSystem.entity.Shop;
import com.orderSystem.entity.User;

public interface shopService {

	public void save(Shop shop);
	public void delete(Shop shop);
	public Shop findShopById(int shopId);
	public List<Shop>findAll();
	public void updateShop(Shop shop);
	public List<Shop> findLikeByName(String name);
	public List<Map<String,String>> getShopList(List<Shop>shop1);
	public List<Shop> orderByShopId();
}
