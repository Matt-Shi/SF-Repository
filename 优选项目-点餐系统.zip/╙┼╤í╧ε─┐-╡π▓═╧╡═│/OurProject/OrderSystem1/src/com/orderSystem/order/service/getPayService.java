package com.orderSystem.order.service;

import java.util.List;

import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Dish;

public interface getPayService {
	int getAddr(String description);//添加送餐地址
	int getOrder(int addrId);//新建订单,返回订单id
	void getPay(String userId, int orderId);//员工卡转账到商家账户
}
