package com.orderSystem.entity;

/**
 * Address entity. @author MyEclipse Persistence Tools
 */
public class Address extends AbstractAddress implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Address() {
	}

	/** full constructor */
	public Address(Integer userId, String description) {
		super(userId, description);
	}

}
