package com.orderSystem.card;
import java.util.List;
import com.orderSystem.entity.Card;
public interface cardService {
	public List<Card> getAllCard();
	public int addCard(Card card);
	public int deleteCard(int cardId);
	public boolean updateCard(Card card);
	public Card findByCardId(Integer cardId);
}
