package com.orderSystem.users;

import java.util.List;

import com.orderSystem.dao.CartDAO;
import com.orderSystem.dao.ShopDAO;
import com.orderSystem.dao.UserDAO;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.User;

public class userServiceImpl implements userService {

	UserDAO userDao=new UserDAO();
	CartDAO cartDao=new CartDAO();
	ShopDAO shopDao=new ShopDAO();
	@Override
	public User userCenter(String username) {
		List<User> userList=userDao.findByUserName(username);
		if(userList.size()!=0)
			return userList.get(0);
		else
			return null;
	}
	@Override
	public String findUserNameById(Integer userid) {
		// TODO Auto-generated method stub
		return userDao.findById(userid).getUserName();
	}
	@Override
	public int[] findShopIdByOrderId(Integer orderId) {
		List<Cart> cartList=cartDao.findByOrderId(orderId);
		int[] shopIds=new int[cartList.size()];
		for(int i=0;i<cartList.size();i++)
		{
			shopIds[i]=cartList.get(i).getShopId();	
		}
		
		/*for(int i=0;i<shopIds.length;i++)
		{
			System.out.println(shopIds[i]);
		}*/
		
		return shopIds;
	}
	@Override
	public String[] findNameByIds(int[] shopIds) {
		// TODO Auto-generated method stub
		String[] shopNames=new String[shopIds.length];
		for(int i=0;i<shopIds.length;i++)
		{
			shopNames[i]=shopDao.findById(shopIds[i]).getShopName();
		}
		return shopNames;
	}

}
