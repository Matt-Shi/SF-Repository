package com.orderSystem.shops.action;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.entity.Dish;
import com.orderSystem.shops.service.searchDishService;

public class searchDishAction {
	private String name;
	private List<Dish> dishList = new ArrayList<Dish>();
	searchDishService searchds;
	
	
 	public String searchDish(){
		dishList = searchds.doSearch(name);
		return "searchResult";
	}

/************Getters and Setters**********************************/
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<Dish> getDishList() {
		return dishList;
	}


	public void setDishList(List<Dish> dishList) {
		this.dishList = dishList;
	}


	public searchDishService getSearchds() {
		return searchds;
	}


	public void setSearchds(searchDishService searchds) {
		this.searchds = searchds;
	}
}
