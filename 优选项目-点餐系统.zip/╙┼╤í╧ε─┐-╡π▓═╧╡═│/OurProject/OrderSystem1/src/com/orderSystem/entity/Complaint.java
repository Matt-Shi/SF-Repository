package com.orderSystem.entity;

/**
 * Complaint entity. @author MyEclipse Persistence Tools
 */
public class Complaint extends AbstractComplaint implements
		java.io.Serializable {

	// Constructors

	/** default constructor */
	public Complaint() {
	}

	/** full constructor */
	public Complaint(Integer userId, Integer shopId, String descript) {
		super(userId, shopId, descript);
	}

}
