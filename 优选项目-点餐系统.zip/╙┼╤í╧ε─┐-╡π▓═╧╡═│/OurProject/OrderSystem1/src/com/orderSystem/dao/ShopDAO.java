package com.orderSystem.dao;

import com.orderSystem.entity.Shop;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.criterion.Example;

/**
 * A data access object (DAO) providing persistence and search support for Shop
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.orderSystem.entity.Shop
 * @author MyEclipse Persistence Tools
 */
public class ShopDAO extends BaseHibernateDAO {
	private static final Log log = LogFactory.getLog(ShopDAO.class);
	// property constants
	public static final String SHOP_NAME = "shopName";
	public static final String SHOP_PHONE = "shopPhone";
	public static final String SHOP_ADDR = "shopAddr";
	public static final String AM_OPEN_TIME = "amOpenTime";
	public static final String AM_CLOSE_TIME = "amCloseTime";
	public static final String PM_OPEN_TIME = "pmOpenTime";
	public static final String PM_CLOSE_TIME = "pmCloseTime";
	public static final String SHOP_DESC = "shopDesc";
	public static final String ACCOUNT = "account";
	public static final String SHOP_PWD = "shopPwd";
	public static final String TYPE_ID = "typeId";
	public static final String SHOP_IMAGE = "shopImage";
	public static final String SHOP_CODE = "shopCode";

	public void save(Shop transientInstance) {
		log.debug("saving Shop instance");
		try {
			getSession().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Shop persistentInstance) {
		log.debug("deleting Shop instance");
		try {
			getSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Shop findById(java.lang.Integer id) {
		log.debug("getting Shop instance with id: " + id);
		try {
			Shop instance = (Shop) getSession().get(
					"com.orderSystem.entity.Shop", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Shop instance) {
		log.debug("finding Shop instance by example");
		try {
			List results = getSession()
					.createCriteria("com.orderSystem.entity.Shop")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Shop instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Shop as model where model."
					+ propertyName + "= ?";
			Query queryObject = getSession().createQuery(queryString);
			queryObject.setParameter(0, value);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByShopName(Object shopName) {
		return findByProperty(SHOP_NAME, shopName);
	}

	public List findByShopPhone(Object shopPhone) {
		return findByProperty(SHOP_PHONE, shopPhone);
	}

	public List findByShopAddr(Object shopAddr) {
		return findByProperty(SHOP_ADDR, shopAddr);
	}

	public List findByAmOpenTime(Object amOpenTime) {
		return findByProperty(AM_OPEN_TIME, amOpenTime);
	}

	public List findByAmCloseTime(Object amCloseTime) {
		return findByProperty(AM_CLOSE_TIME, amCloseTime);
	}

	public List findByPmOpenTime(Object pmOpenTime) {
		return findByProperty(PM_OPEN_TIME, pmOpenTime);
	}

	public List findByPmCloseTime(Object pmCloseTime) {
		return findByProperty(PM_CLOSE_TIME, pmCloseTime);
	}

	public List findByShopDesc(Object shopDesc) {
		return findByProperty(SHOP_DESC, shopDesc);
	}

	public List findByAccount(Object account) {
		return findByProperty(ACCOUNT, account);
	}

	public List findByShopPwd(Object shopPwd) {
		return findByProperty(SHOP_PWD, shopPwd);
	}

	public List findByTypeId(Object typeId) {
		return findByProperty(TYPE_ID, typeId);
	}

	public List findByShopImage(Object shopImage) {
		return findByProperty(SHOP_IMAGE, shopImage);
	}

	public List findByShopCode(Object shopCode) {
		return findByProperty(SHOP_CODE, shopCode);
	}

	public List findAll() {
		log.debug("finding all Shop instances");
		try {
			String queryString = "from Shop";
			Query queryObject = getSession().createQuery(queryString);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Shop merge(Shop detachedInstance) {
		log.debug("merging Shop instance");
		try {
			Shop result = (Shop) getSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Shop instance) {
		log.debug("attaching dirty Shop instance");
		try {
			getSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Shop instance) {
		log.debug("attaching clean Shop instance");
		try {
			getSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
}