package com.orderSystem.shops.service;

import java.util.List;

import com.orderSystem.entity.Dish;

public interface showNewDishService {
	List<Dish> doShow();
}
