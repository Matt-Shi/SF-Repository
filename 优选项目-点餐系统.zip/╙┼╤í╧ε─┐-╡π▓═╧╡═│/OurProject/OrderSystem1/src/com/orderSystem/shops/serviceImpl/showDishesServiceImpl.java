package com.orderSystem.shops.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.dao.DishDAO;
import com.orderSystem.entity.Dish;
import com.orderSystem.shops.service.showDishesService;

public class showDishesServiceImpl implements showDishesService{

	@Override
	public List<Dish> doShow(String shopId) {
		// TODO Auto-generated method stub
		
		DishDAO dishdao = new DishDAO();
		List<Dish> dishList = new ArrayList<Dish>();
		
		dishList = dishdao.findByShopId(Integer.valueOf(shopId));
		
		if(dishList != null)
			return dishList;
		
		return null;
	}

}
