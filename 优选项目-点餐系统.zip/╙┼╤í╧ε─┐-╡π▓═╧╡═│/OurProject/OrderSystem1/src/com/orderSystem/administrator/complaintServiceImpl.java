package com.orderSystem.administrator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.orderSystem.dao.ComplaintDAO;
import com.orderSystem.entity.Complaint;
import com.orderSystem.entity.User;

public class complaintServiceImpl implements complaintService {

	private ComplaintDAO complaintDao;
	private userService userService;
	public userService getUserService() {
		return userService;
	}

	public void setUserService(userService userService) {
		this.userService = userService;
	}

	public ComplaintDAO getComplaintDao() {
		return complaintDao;
	}

	public void setComplaintDao(ComplaintDAO complaintDao) {
		this.complaintDao = complaintDao;
	}

	@Override
	public void save(Complaint complaint) {
		// TODO Auto-generated method stub
		Transaction ts = complaintDao.getSession().beginTransaction();
		complaintDao.save(complaint);
		ts.commit();
		complaintDao.getSession().close();
	}

	@Override
	public void delete(Complaint complaint) {
		// TODO Auto-generated method stub
		if(complaintDao.findById(complaint.getComplaintId())!=null){
			Transaction ts = complaintDao.getSession().beginTransaction();
			complaintDao.delete(complaint);
			ts.commit();
			complaintDao.getSession().close();
		}
	}

	@Override
	public Complaint findComplaintById(int complaintId) {
		// TODO Auto-generated method stub
		return complaintDao.findById(complaintId);
	}

	@Override
	public List<Complaint> findAll() {
		// TODO Auto-generated method stub
		return complaintDao.findAll();
	}

	@Override
	public void update(Complaint complaint) {
		// TODO Auto-generated method stub
		Transaction ts = complaintDao.getSession().beginTransaction();
		complaintDao.merge(complaint);
		ts.commit();
		complaintDao.getSession().close();
	}

	@Override
	public List<Complaint> findComplaintByShopId(int shopId) {
		// TODO Auto-generated method stub
		return complaintDao.findByShopId(shopId);
	}

	@Override
	public List<Complaint> findComplaintByUserId(int userId) {
		// TODO Auto-generated method stub
		return complaintDao.findByUserId(userId);
	}

	@Override
	public List<Complaint> findLikeByName(String name) {
		// TODO Auto-generated method stub
		List<User>userlist=userService.findByUserName(name);
		try{
			name="'%"+name+"%'";
			Query query = complaintDao.getSession().createQuery("from complaint where userName like "+name+" or role like "+name+" or userPhone like "+name);
			List<Complaint>list = query.list();
			return list;
		}catch(RuntimeException ex){
			throw ex;
	}
	}

	//@Override
	/*public List<Map<String, String>> getComplaintList(List<Complaint> comp,
			String key) {
		// TODO Auto-generated method stub
		List<Map<String,String>>templist=new ArrayList<Map<String,String>>();
		Iterator<Complaint> it=comp.iterator();
		while(it.hasNext()){
			Map<String,String>map=new HashMap<String, String>();
			Complaint temp=it.next();
			int userId = temp.getUserId();
			int shopId = temp.getShopId();
			String desc = temp.getDescript();
			int compId=temp.getComplaintId();
			
			map.put("userName", getUserName(userId));
			map.put("shopName", getShopName(shopId));
			map.put("desc", desc);
			templist.add(map);
		}
		return null;
	}*/

}
