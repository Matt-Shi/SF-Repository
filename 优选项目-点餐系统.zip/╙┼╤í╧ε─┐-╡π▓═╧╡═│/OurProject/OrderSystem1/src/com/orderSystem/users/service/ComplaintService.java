package com.orderSystem.users.service;

import java.util.List;

import com.orderSystem.entity.Complaint;

/*操作投诉表complaint的服务层接口*/
public interface ComplaintService {

	Complaint findComplaintById(int id); // 通过complaintId查询其对应的投诉信息

	List<Complaint> findComplaintByUserId(int id);// 通过userId查询其对应的投诉记录列表

	void deleteComplaintById(int id);

	boolean saveComplaint(Complaint complaint);
}
