package com.orderSystem.shops.action;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.entity.Shop;
import com.orderSystem.shops.service.showClosedShopService;
import com.orderSystem.shops.service.showShopService;

public class showShopAction {
	private String shopType;//商家类型
	//保存营业中商家信息
	private List<Shop> openList = new ArrayList<Shop>();
	//保存闭业中的商家信息
	private List<Shop> closedList = new ArrayList<Shop>();
	showShopService sss;
	showClosedShopService scss;
	
	//打开商家列表
	public String showShops(){
		openList = sss.doShow(shopType);
		closedList = scss.doShow(shopType);
		return "shopHomepage";
	}
	
/********************Getters and Setters****************************/

    public String getShopType() {
		return shopType;
	}

	public void setShopType(String shopType) {
		this.shopType = shopType;
	}
	
	public showShopService getSss() {
		return sss;
	}

	public void setSss(showShopService sss) {
		this.sss = sss;
	}

	public List<Shop> getClosedList() {
		return closedList;
	}

	public void setClosedList(List<Shop> closedList) {
		this.closedList = closedList;
	}

	public showClosedShopService getScss() {
		return scss;
	}

	public void setScss(showClosedShopService scss) {
		this.scss = scss;
	}

	public List<Shop> getOpenList() {
		return openList;
	}

	public void setOpenList(List<Shop> openList) {
		this.openList = openList;
	}


}
