package com.orderSystem.administrator;

import java.util.List;
import java.util.Map;

import com.orderSystem.entity.Complaint;
import com.orderSystem.entity.Shop;

public interface complaintService {

	public void save(Complaint complaint);
	public void delete(Complaint complaint);
	public Complaint findComplaintById(int comId);
	public List<Complaint> findComplaintByShopId(int shopId);
	public List<Complaint> findComplaintByUserId(int userId);
	public List<Complaint>findAll();
	public void update(Complaint complaint);
	public List<Complaint> findLikeByName(String name);
	/*public List<Map<String,String>> getComplaintList(List<Complaint>comp,String key);*/
}
