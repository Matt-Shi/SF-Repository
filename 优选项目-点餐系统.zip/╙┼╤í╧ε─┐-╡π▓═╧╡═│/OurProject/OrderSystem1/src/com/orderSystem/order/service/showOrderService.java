package com.orderSystem.order.service;

import java.util.List;

import com.orderSystem.entity.Cart;

public interface showOrderService {
	List<Cart> showCart(String shopId);
}
