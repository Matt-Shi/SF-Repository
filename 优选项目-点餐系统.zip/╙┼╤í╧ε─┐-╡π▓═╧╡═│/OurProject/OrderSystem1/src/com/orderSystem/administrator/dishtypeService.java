package com.orderSystem.administrator;

import java.util.List;

import com.orderSystem.entity.DishType;

public interface dishtypeService {

	public void save(DishType dishtype);
	public void delete(DishType dishtype);
	public DishType findDIshTypeById(int TypeId);
	public List<DishType> findByTypeName(String typeName);
	public List<DishType>findAll();
	public void update(DishType dishtype);
}
