package com.orderSystem.shops.action;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.entity.Dish;
import com.orderSystem.shops.service.showDishesService;

public class showDishAction {
	private String shopId;
	private List<Dish> dishList = new ArrayList<Dish>();
	showDishesService showdish;
	
	//显示某个商家所提供的所有菜品信息
	public String showDishes(){
		dishList = showdish.doShow(shopId);
		shopId = shopId;
		return "dishHomepage";
	}
	
	
	
	
	
/******************Getter and Setter*******************************/
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public List<Dish> getDishList() {
		return dishList;
	}
	public void setDishList(List<Dish> dishList) {
		this.dishList = dishList;
	}

	public showDishesService getShowdish() {
		return showdish;
	}

	public void setShowdish(showDishesService showdish) {
		this.showdish = showdish;
	}
}
