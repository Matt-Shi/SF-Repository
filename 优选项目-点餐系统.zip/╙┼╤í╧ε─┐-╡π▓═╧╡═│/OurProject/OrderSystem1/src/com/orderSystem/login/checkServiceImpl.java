package com.orderSystem.login;
import java.util.List;
import com.orderSystem.dao.ShopDAO;
import com.orderSystem.dao.UserDAO;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.User;

public class checkServiceImpl implements checkService {
	// ����û���¼��Ϣ�Ƿ���ȷ
	public int doCheck(String userName, String pwd) {
		if (userName == null) {
			System.out.println("��");
			return 0;
		}
		UserDAO udao = new UserDAO();
		List<User> list = udao.findByUserName(userName);
		if (list.size() == 0)
			return 0;
		else {
			User user = list.get(0);
			if (user == null)
				return 0;
			else if (user.getPwd().equals(pwd))
				return 1;
		}
		return 0;
	}

	ShopDAO shopdao = new ShopDAO();

	public ShopDAO getShopDao() {
		return shopdao;
	}

	public void setShopDao(ShopDAO shopDao) {
		this.shopdao = shopDao;
	}

	// ����̼���Ϣ
	public void add(Shop shop) {
		// TODO Auto-generated method stub
		org.hibernate.Transaction tr = shopdao.getSession().beginTransaction();
		List<User> list = shopdao.findByShopName(shop.getShopName());
		if (list.size() == 0)
			shopdao.save(shop);
		else
			System.out.println("�̼�ע�������⣡��");
		tr.commit();
		shopdao.getSession().close();

	}

	@Override
	public int shopCheck(String shopCode, String shopPwd) {
		if (shopCode == null) {
			//System.out.println("��");
			return 0;
		}
		ShopDAO sdao = new ShopDAO();
		List<Shop> list = sdao.findByShopCode(shopCode);
		if (list.size() == 0)
			return 0;
		else {
			Shop shop = list.get(0);
			if (shop == null)
				return 0;
			else if (shop.getShopPwd().equals(shopPwd))
				return 1;
		}
		return 0;
	}
	
}
