package com.orderSystem.users;

import com.orderSystem.entity.User;

public interface userService {
	public User userCenter(String username);
	public String findUserNameById(Integer userid);
	
	public int[] findShopIdByOrderId(Integer orderId);
	public String[] findNameByIds(int[] shopIds);
}
