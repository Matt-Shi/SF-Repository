package com.orderSystem.cart;


public interface cartService {
	public int[] findShopIdByOrderId(Integer orderId);
}
