package com.orderSystem.order.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.dao.CartDAO;
import com.orderSystem.dao.DishDAO;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Dish;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.order.service.showOrderService;
import javax.servlet.http.*;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Transaction;

import java.util.Enumeration;

public class showOrderServiceImpl implements showOrderService{

	@Override
	public List<Cart> showCart(String shopId) {
		// TODO Auto-generated method stub
		List<Cart> cartList = new ArrayList<Cart>();//保存购物车列表
		List<Dish> dishList = new ArrayList<Dish>();
		DishDAO dishdao = new DishDAO();
		Dish dish = new Dish();
		CartDAO cartdao = new CartDAO();
		
		long price;//保存单价
		int numb;//保存数量
		
		HttpServletRequest request = ServletActionContext.getRequest();
		Enumeration paramNames = request.getParameterNames();
		int kk = 1;
		while (paramNames.hasMoreElements()){  
			Cart cart = new Cart();
			
			String paramName = (String) paramNames.nextElement();
			if(request.getParameter("item_name"+"_"+kk) == null)
				break;
			dishList = dishdao.findByDishName(request.getParameter("item_name"+"_"+kk));
			//获取菜品单价
			price = Long.valueOf(request.getParameter("amount_"+kk));
			//获取菜品数量
			numb = Integer.valueOf(request.getParameter("quantity_"+kk));
			
			dish = dishList.get(0);
			//dishList.add(dish);
			cart.setDishId(dish.getDishId());
			cart.setShopId(Integer.valueOf(shopId));
			cart.setDishNumber(numb);
			cart.setCartPrice(price*numb);
			cart.setStatus("未受理");
			cartList.add(cart);
			
			//保存购物车
			Transaction tr = cartdao.getSession().beginTransaction();
			cartdao.save(cart);
			tr.commit();
			cartdao.getSession().close();
			//cart表主键为自增，当cart对象存进数据库之后，主键能够自动生成，能够在transaction关闭之后后拿出来
			/*System.out.println(request.getParameter("shop_Id"));*/
			
			kk++;
		}
		return cartList;
	}

}
