package com.orderSystem.users.service;

import java.util.List;

import com.orderSystem.entity.Favorite;

/*操作收藏表favorite的服务层接口*/
public interface FavoriteService {

	Favorite findFavoriteById(int id);// 通过favoriteId查询其对应的收藏信息

	List<Favorite> findFavoriteByUserId(int userId);// 通过userId查询其对应的收藏列表信息

	void deleteFavoriteById(int favId);// 通过favoriteId删除其对应的收藏信息
}
