package com.orderSystem.entity;

/**
 * AbstractCard entity provides the base persistence definition of the Card
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractCard implements java.io.Serializable {

	// Fields

	private Integer cardId;
	private Long balance;

	// Constructors

	/** default constructor */
	public AbstractCard() {
	}

	/** full constructor */
	public AbstractCard(Long balance) {
		this.balance = balance;
	}

	// Property accessors

	public Integer getCardId() {
		return this.cardId;
	}

	public void setCardId(Integer cardId) {
		this.cardId = cardId;
	}

	public Long getBalance() {
		return this.balance;
	}

	public void setBalance(Long balance) {
		this.balance = balance;
	}

}