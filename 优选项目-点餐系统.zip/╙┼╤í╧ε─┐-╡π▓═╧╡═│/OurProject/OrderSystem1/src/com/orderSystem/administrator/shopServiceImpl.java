package com.orderSystem.administrator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Transaction;

import com.orderSystem.dao.DishTypeDAO;
import com.orderSystem.dao.ShopDAO;
import com.orderSystem.entity.DishType;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.User;

public class shopServiceImpl implements shopService {

	private ShopDAO shopDao;
	//private shopService shopService;
	private dishtypeService dishtypeService;
	/*public shopService getShopService() {
		return shopService;
	}

	public void setShopService(shopService shopService) {
		this.shopService = shopService;
	}*/

	public dishtypeService getDishtypeService() {
		return dishtypeService;
	}

	public void setDishtypeService(dishtypeService dishtypeService) {
		this.dishtypeService = dishtypeService;
	}

	public ShopDAO getShopDao() {
		return shopDao;
	}

	public void setShopDao(ShopDAO shopDao) {
		this.shopDao = shopDao;
	}

	@Override
	public void save(Shop shop) {
		// TODO Auto-generated method stub
		Transaction ts = shopDao.getSession().beginTransaction();
		shopDao.save(shop);
		ts.commit();
		shopDao.getSession().close();
	}

	@Override
	public void delete(Shop shop) {
		// TODO Auto-generated method stub
		if(shopDao.findById(shop.getShopId())!=null){
			Transaction ts = shopDao.getSession().beginTransaction();
			shopDao.delete(shop);
			ts.commit();
			shopDao.getSession().close();
		}
	}

	@Override
	public Shop findShopById(int shopId) {
		// TODO Auto-generated method stub
		return shopDao.findById(shopId);
	}

	@Override
	public List<Shop> findAll() {
		// TODO Auto-generated method stub
		return shopDao.findAll();
	}

	@Override
	public void updateShop(Shop shop) {
		// TODO Auto-generated method stub
		Transaction ts = shopDao.getSession().beginTransaction();
		shopDao.merge(shop);
		ts.commit();
		shopDao.getSession().close();
	}

	@Override
	public List<Shop> findLikeByName(String name) {
		// TODO Auto-generated method stub
		try{
			int typeId=-1;
			if(dishtypeService.findByTypeName(name).size()!=0){
				List<DishType>dishlist = dishtypeService.findByTypeName(name);
				typeId = dishlist.get(0).getTypeId();
			}
			name="'%"+name+"%'";
			/*Query query = shopDao.getSession().createQuery("from Shop,DishType where Shop.shop_name like "+name+" or Shop.shop_phone like "
					+name+" or Shop.shop_addr like "+name+" or Shop.shop_desc like "+name+" or DishType.typeId like "+typeId);*/
			Query query = shopDao.getSession().createQuery("from Shop where shop_name like "+name+" or shop_phone like "+name+
					" or shop_addr like "+name+ " or shop_desc like "+name+" or typeId like "+typeId);
			List<Shop>list = query.list();
			return list;
		}catch(RuntimeException ex){
			throw ex;
	}
	}

	@Override
	public List<Map<String, String>> getShopList(List<Shop>templist) {
		// TODO Auto-generated method stub
		List<Map<String,String>>shoplist = new ArrayList<Map<String,String>>();
		Iterator<Shop>it = templist.iterator();
		while(it.hasNext()){
			Map<String ,String>map = new HashMap<String, String>();
			Shop tempshop = it.next();
			map.put("shopId", Integer.toString(tempshop.getShopId()));
			map.put("shopName", tempshop.getShopName());
			map.put("shopAddr",tempshop.getShopAddr());
			map.put("shopPhone", tempshop.getShopPhone());
			map.put("account", Long.toString(tempshop.getAccount()));
			String dishtype = dishtypeService.findDIshTypeById(tempshop.getTypeId()).getTypeName();
			map.put("dishtype", dishtype);
			shoplist.add(map);
		}
		return shoplist;
	}

	@Override
	public List<Shop> orderByShopId() {
		// TODO Auto-generated method stub
		Query q = shopDao.getSession().createQuery("from Shop order by shop_id desc");
		List<Shop>li = (List<Shop>)q.list();
		return li;
	}

}
