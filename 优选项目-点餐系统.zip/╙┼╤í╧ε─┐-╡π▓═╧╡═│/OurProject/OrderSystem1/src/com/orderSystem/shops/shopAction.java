package com.orderSystem.shops;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.Address;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Complaint;
import com.orderSystem.entity.Dish;
import com.orderSystem.entity.DishType;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.entity.User;

public class shopAction {
	private Shop shop;
	private String name;
	ShopService shopService;
	private int shopId;
	private String shopName;
	private String shopType;
	private String amOpen;
	private String amClose;
	private String pmOpen;
	private String pmClose;
	private String shopPhone;
	private String shopAddr;
	private String shopDesc;
	private File shopImage;
	private String shopImageFileName;
	private String shopImageContentType;
	private int cartId;
	private String keywords;
	public String getShopById()
	{	
		shop=shopService.getShopById(shopId);
		ActionContext context=ActionContext.getContext();
		context.getSession().put("shopId", shopId);
		String shoptype=shopService.getShopTypeById(shopId);
		context.put("shop", shop);
		context.put("shoptype", shoptype);
		String temp=shop.getAmOpenTime();
		String amOpen=temp.substring(0, 2)+":"+temp.substring(2, 4);
		context.put("amOpen", amOpen);
		temp=shop.getAmCloseTime();
		String amClose=temp.substring(0, 2)+":"+temp.substring(2, 4);
		context.put("amClose", amClose);
		temp=shop.getPmOpenTime();
		String pmOpen=temp.substring(0, 2)+":"+temp.substring(2, 4);
		context.put("pmOpen", pmOpen);
		temp=shop.getPmCloseTime();
		String pmClose=temp.substring(0, 2)+":"+temp.substring(2, 4);
		context.put("pmClose", pmClose);
		return "shopbyid";
	}
	public String editShop()
	{
		shop=shopService.getShopById(shopId);
		String shoptype=shopService.getShopTypeById(shopId);
		ActionContext context=ActionContext.getContext();
		context.put("shop", shop);
		context.put("shoptype", shoptype);
		String temp=shop.getAmOpenTime();
		String amOpen=temp.substring(0, 2)+":"+temp.substring(2, 4);
		context.put("amOpen", amOpen);
		temp=shop.getAmCloseTime();
		String amClose=temp.substring(0, 2)+":"+temp.substring(2, 4);
		context.put("amClose", amClose);
		temp=shop.getPmOpenTime();
		String pmOpen=temp.substring(0, 2)+":"+temp.substring(2, 4);
		context.put("pmOpen", pmOpen);
		temp=shop.getPmCloseTime();
		String pmClose=temp.substring(0, 2)+":"+temp.substring(2, 4);
		context.put("pmClose", pmClose);
		
		List<DishType> shopTypes=shopService.getAllShopType();
		context.put("shopTypes", shopTypes);
		context.put("am_service_time", shopUtils.AM_SERVICE_TIME);
		context.put("pm_service_time", shopUtils.PM_SERVICE_TIME);
		return "editshop";
	}
	
	public String updateShopSuccess() throws Exception
	{
		shop=shopService.getShopById(shopId);
		int typeId=shopService.getTypeIdByTypeName(shopType);
		System.out.println("typeId="+typeId);
		ActionContext context=ActionContext.getContext();
		context.put("shoptype", shopType);
		String amOpen2=amOpen.substring(0,2)+amOpen.substring(3,5);
		String amClose2=amClose.substring(0,2)+amClose.substring(3,5);
		String pmOpen2=pmOpen.substring(0,2)+pmOpen.substring(3,5);
		String pmClose2=pmClose.substring(0,2)+pmClose.substring(3,5);
		Shop shop2=null;
		if(shopImage!=null){
			String newfilename="shop/uploads/shop"+System.currentTimeMillis()+
					shopImageFileName.substring(shopImageFileName.length()-5);
			InputStream is = new FileInputStream(shopImage);
			String path=((ServletContext)(ActionContext.getContext().
					get(ServletActionContext.SERVLET_CONTEXT))).getRealPath("/");
			File newFile = new File(path,newfilename);
			OutputStream os=new FileOutputStream(newFile);
			byte[] buffer = new byte[400];
			int length=0;
			while((length = is.read(buffer))>0)
			{
				os.write(buffer,0,length);
			}
			is.close();
			os.close();
		
		shop2=new Shop(shopName, shopPhone, shopAddr, shopDesc, shop.getAccount(), shop.getShopPwd(), typeId, newfilename, shop.getShopCode(), amOpen2, amClose2, pmOpen2, pmClose2);
		shop2.setShopId(shopId);
		shopService.updateShop(shop2);
		}else
		{
			shop2=new Shop(shopName, shopPhone, shopAddr, shopDesc, shop.getAccount(), shop.getShopPwd(), typeId, shop.getShopImage(), shop.getShopCode(), amOpen2, amClose2, pmOpen2, pmClose2);
			shop2.setShopId(shopId);
			shopService.updateShop(shop2);
		}
		return "updateShopSuccess";
	}
	public String getShopAllComplaint()
	{
		List<Complaint> complaints=shopService.getAllComplaintByShopId(shopId);
		ActionContext context=ActionContext.getContext();
		if(complaints.size()>=1)
		{
			List<String> usernames=new ArrayList<String>();
			for(Complaint c:complaints)
			{
				usernames.add(shopService.getUserNameById(c.getUserId()));
			}
			
			context.put("complaints", complaints);
			context.put("complaintSize", complaints.size());
			context.put("usernames", usernames);
		}else
		{
			context.put("complaintSize", 0);
		}
		return "getShopAllComplaint";
	}
	public String getAllCart()
	{
		List<Cart> carts=shopService.getAllCart(shopId);
		System.out.println("cart_size="+carts.size());
		if(carts.size()>=1)
		{
			ActionContext context=ActionContext.getContext();
			List<String> dishNames=new ArrayList<String>();
			List<ShopOrder> ShopOrders=new ArrayList<ShopOrder>();
			for(Cart cart:carts)
			{
				dishNames.add(shopService.getDishName(cart.getDishId()));
				ShopOrders.add(shopService.getOrderById(cart.getOrderId()));
			}
			List<User> users=new ArrayList<User>();
			List<Address> addrs=new ArrayList<Address>();
			for(ShopOrder ShopOrder:ShopOrders)
			{
				users.add(shopService.getUserById(ShopOrder.getUserId()));
				addrs.add(shopService.getAddressById(ShopOrder.getAddrId()));
			}
			
			context.put("carts", carts);
			context.put("cartSize", carts.size());
			context.put("dishNames", dishNames);
			context.put("users", users);
			context.put("addrs", addrs);
		}
		return "getAllCart";
	}
	
	public String changeCartStatus()
	{
		
		shopService.ChangeCartStatus(cartId);
		
		List<Cart> carts=shopService.getAllCart(shopId);
		System.out.println("cart_size="+carts.size());
		ActionContext context=ActionContext.getContext();
		if(carts.size()>=1)
		{
			
			List<String> dishNames=new ArrayList<String>();
			List<ShopOrder> ShopOrders=new ArrayList<ShopOrder>();
			for(Cart cart:carts)
			{
				dishNames.add(shopService.getDishName(cart.getDishId()));
				ShopOrders.add(shopService.getOrderById(cart.getOrderId()));
			}
			List<User> users=new ArrayList<User>();
			List<Address> addrs=new ArrayList<Address>();
			for(ShopOrder ShopOrder:ShopOrders)
			{
				users.add(shopService.getUserById(ShopOrder.getUserId()));
				addrs.add(shopService.getAddressById(ShopOrder.getAddrId()));
			}
			
			context.put("carts", carts);
			context.put("cartSize", carts.size());
			context.put("dishNames", dishNames);
			context.put("users", users);
			context.put("addrs", addrs);
		}else
		{
			//当订单表为空时，不报异常
			context.put("cartSize", 0);
		}
		return "changeCartStatus";
	}
	public String getCartByLikeUserName()
	{
		ActionContext context=ActionContext.getContext();
		//System.out.println(shopId);
		//List<Dish> dishes=shopService.get
		List<Cart> carts=shopService.getCartByLikeUserName(keywords, shopId);
		//System.out.println("size:"+dishes.size());
		//context.put("shopId", shopId);
		
		System.out.println("cart_size="+carts.size());
		if(carts.size()>=1)
		{
			//ActionContext context=ActionContext.getContext();
			List<String> dishNames=new ArrayList<String>();
			List<ShopOrder> ShopOrders=new ArrayList<ShopOrder>();
			for(Cart cart:carts)
			{
				dishNames.add(shopService.getDishName(cart.getDishId()));
				ShopOrders.add(shopService.getOrderById(cart.getOrderId()));
			}
			List<User> users=new ArrayList<User>();
			List<Address> addrs=new ArrayList<Address>();
			for(ShopOrder ShopOrder:ShopOrders)
			{
				users.add(shopService.getUserById(ShopOrder.getUserId()));
				addrs.add(shopService.getAddressById(ShopOrder.getAddrId()));
			}
			
			context.put("carts", carts);
			context.put("cartSize", carts.size());
			context.put("dishNames", dishNames);
			context.put("users", users);
			context.put("addrs", addrs);
		}else
		{
			context.put("cartSize", 0);
		}
		return "getCartByLikeUserName";
	}
	public String getComplaintByLikeUserName()
	{
		List<Complaint> complaints=shopService.getComplaintByLikeUserName(keywords, shopId);
		ActionContext context=ActionContext.getContext();
		if(complaints.size()>=1)
		{
			List<String> usernames=new ArrayList<String>();
			for(Complaint c:complaints)
			{
				usernames.add(shopService.getUserNameById(c.getUserId()));
			}
			
			context.put("complaints", complaints);
			context.put("complaintSize", complaints.size());
			context.put("usernames", usernames);
		}else
		{
			context.put("complaintSize", 0);
		}
		return "getComplaintByLikeUserName";
	}
	
	public ShopService getShopService() {
		return shopService;
	}
	public void setShopService(ShopService shopService) {
		this.shopService = shopService;
	}
	public Shop getShop() {
		return shop;
	}
	public void setShop(Shop shop) {
		this.shop = shop;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopType() {
		return shopType;
	}
	public void setShopType(String shopType) {
		this.shopType = shopType;
	}
	public String getAmOpen() {
		return amOpen;
	}
	public void setAmOpen(String amOpen) {
		this.amOpen = amOpen;
	}
	public String getAmClose() {
		return amClose;
	}
	public void setAmClose(String amClose) {
		this.amClose = amClose;
	}
	public String getPmOpen() {
		return pmOpen;
	}
	public void setPmOpen(String pmOpen) {
		this.pmOpen = pmOpen;
	}
	public String getPmClose() {
		return pmClose;
	}
	public void setPmClose(String pmClose) {
		this.pmClose = pmClose;
	}
	public String getShopAddr() {
		return shopAddr;
	}
	public void setShopAddr(String shopAddr) {
		this.shopAddr = shopAddr;
	}
	public String getShopDesc() {
		return shopDesc;
	}
	public void setShopDesc(String shopDesc) {
		this.shopDesc = shopDesc;
	}
	public String getShopPhone() {
		return shopPhone;
	}
	public void setShopPhone(String shopPhone) {
		this.shopPhone = shopPhone;
	}
	public File getShopImage() {
		return shopImage;
	}
	public void setShopImage(File shopImage) {
		this.shopImage = shopImage;
	}
	public String getShopImageFileName() {
		return shopImageFileName;
	}
	public void setShopImageFileName(String shopImageFileName) {
		this.shopImageFileName = shopImageFileName;
	}
	public String getShopImageContentType() {
		return shopImageContentType;
	}
	public void setShopImageContentType(String shopImageContentType) {
		this.shopImageContentType = shopImageContentType;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	
}
