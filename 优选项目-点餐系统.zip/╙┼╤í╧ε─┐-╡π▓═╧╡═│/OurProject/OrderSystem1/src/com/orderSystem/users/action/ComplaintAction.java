package com.orderSystem.users.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.Complaint;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.User;
import com.orderSystem.shops.service.ShopService;
import com.orderSystem.users.service.ComplaintService;
import com.orderSystem.users.service.UserService;

public class ComplaintAction {

	private int complaintId;
	private int userId;
	private int shopId;
	private String descript;

	ComplaintService complaintService;
	UserService userService;
	ShopService shopService;

	/*=======action methods========*/
	
//	根据userId查询用户对商家的投诉记录列表
	public String getComplaintByUserId() {

		List<Complaint> complaints = complaintService
				.findComplaintByUserId(userId);
		User user = userService.findUserById(userId);
		Map<Integer, Shop> complaintShopMap = new HashMap<Integer, Shop>();
		for (Complaint comp : complaints) {
			complaintShopMap.put(comp.getComplaintId(),
					shopService.findShopById(comp.getShopId()));
		}
		ActionContext ac = ActionContext.getContext();
		ac.put("userId", userId);
		ac.put("user", user);
		ac.put("complaints", complaints);
		ac.put("complaintShopMap", complaintShopMap);
		return "show";
	}

//	传参，然后跳转
	public String addComplaint() {
		ActionContext ac = ActionContext.getContext();
		User user = userService.findUserById(userId);
		Shop shop = shopService.findShopById(shopId);
		ac.put("user", user);
		ac.put("shop", shop);
		return "add";
	}

//	添加用户对商家的投诉或建议
	public String isComplaintAdded() {
		Complaint complaint = new Complaint();
		complaint.setComplaintId(Integer.MAX_VALUE);
		complaint.setShopId(shopId);
		complaint.setUserId(userId);
		complaint.setDescript(descript);

		boolean isAdded = complaintService.saveComplaint(complaint);
		List<Complaint> complaints = complaintService
				.findComplaintByUserId(userId);
		Map<Integer, Shop> complaintShopMap = new HashMap<Integer, Shop>();
		for (Complaint comp : complaints) {
			complaintShopMap.put(comp.getComplaintId(),
					shopService.findShopById(comp.getShopId()));
		}
		ActionContext ac = ActionContext.getContext();
		User user = userService.findUserById(userId);
		ac.put("idAdded", isAdded);
		ac.put("complaintShopMap", complaintShopMap);
		ac.put("complaints", complaints);
		ac.put("user", user);
		return "isAddedSuccess";
	}

	/*=======getters and setters========*/
	
	public int getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getDescript() {
		return descript;
	}

	public void setDescript(String descript) {
		this.descript = descript;
	}

	public ComplaintService getComplaintService() {
		return complaintService;
	}

	public void setComplaintService(ComplaintService complaintService) {
		this.complaintService = complaintService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public ShopService getShopService() {
		return shopService;
	}

	public void setShopService(ShopService shopService) {
		this.shopService = shopService;
	}

}
