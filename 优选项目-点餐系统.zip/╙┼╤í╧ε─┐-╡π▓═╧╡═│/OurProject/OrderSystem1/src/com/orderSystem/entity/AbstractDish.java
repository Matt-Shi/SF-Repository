package com.orderSystem.entity;

import java.sql.Timestamp;

/**
 * AbstractDish entity provides the base persistence definition of the Dish
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractDish implements java.io.Serializable {

	// Fields

	private Integer dishId;
	private String dishName;
	private Long dishPrice;
	private Integer shopId;
	private String imageUrl;
	private Timestamp addTime;

	// Constructors

	/** default constructor */
	public AbstractDish() {
	}

	/** full constructor */
	public AbstractDish(String dishName, Long dishPrice, Integer shopId,
			String imageUrl, Timestamp addTime) {
		this.dishName = dishName;
		this.dishPrice = dishPrice;
		this.shopId = shopId;
		this.imageUrl = imageUrl;
		this.addTime = addTime;
	}

	// Property accessors

	public Integer getDishId() {
		return this.dishId;
	}

	public void setDishId(Integer dishId) {
		this.dishId = dishId;
	}

	public String getDishName() {
		return this.dishName;
	}

	public void setDishName(String dishName) {
		this.dishName = dishName;
	}

	public Long getDishPrice() {
		return this.dishPrice;
	}

	public void setDishPrice(Long dishPrice) {
		this.dishPrice = dishPrice;
	}

	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public String getImageUrl() {
		return this.imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Timestamp getAddTime() {
		return this.addTime;
	}

	public void setAddTime(Timestamp addTime) {
		this.addTime = addTime;
	}

}