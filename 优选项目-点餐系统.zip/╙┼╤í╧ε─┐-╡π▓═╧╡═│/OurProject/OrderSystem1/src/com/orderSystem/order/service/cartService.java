package com.orderSystem.order.service;

import java.util.List;

import com.orderSystem.entity.Cart;

/*操作购物车表cart的服务层接口*/
public interface cartService {
	Cart findCartById(int id);// 根据cartId查询其对应的购物车信息

	List<Cart> findCartByOrderId(int orderId); // 根据orderId查询其对应的购物车列表
}
