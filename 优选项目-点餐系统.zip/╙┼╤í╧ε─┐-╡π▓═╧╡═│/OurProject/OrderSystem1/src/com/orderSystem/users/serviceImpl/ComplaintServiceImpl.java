package com.orderSystem.users.serviceImpl;

import java.util.List;

import org.hibernate.Transaction;

import com.orderSystem.dao.ComplaintDAO;
import com.orderSystem.entity.Complaint;
import com.orderSystem.users.service.ComplaintService;

/*操作投诉表complaint的服务层接口实现类*/
public class ComplaintServiceImpl implements ComplaintService {

	ComplaintDAO complaintDao = new ComplaintDAO();
	@Override
	public Complaint findComplaintById(int id) {
		return complaintDao.findById(id);
	}
	@Override
	public List<Complaint> findComplaintByUserId(int id) {
		return complaintDao.findByUserId(id);
	}
	@Override
	public void deleteComplaintById(int id) {
		Transaction tr = complaintDao.getSession().beginTransaction();
		Complaint complaint = null;
		if ((complaint = complaintDao.findById(id)) != null)
			complaintDao.delete(complaint);
		tr.commit();
		complaintDao.getSession().close();
	}
	@Override
	public boolean saveComplaint(Complaint complaint) {
		try {
			Transaction tr = complaintDao.getSession().beginTransaction();
			if (complaintDao.findById(complaint.getComplaintId()) == null)
				complaintDao.save(complaint);
			tr.commit();
			complaintDao.getSession().close();
		} catch (Exception e) {
			return false;
		}
		return true;
	}

}
