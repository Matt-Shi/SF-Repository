package com.orderSystem.order.serviceImpl;

import java.util.List;

import com.orderSystem.dao.ShopOrderDAO;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.order.service.checkOrderService;

/*操作订单表shop_order的服务层接口实现类*/
public class checkOrderServiceImpl implements checkOrderService {

	ShopOrderDAO shopOrderDao = new ShopOrderDAO();
	@Override
	public ShopOrder findShopOrderById(int id) {
		
		return shopOrderDao.findById(id);
	}
	@Override
	public List<ShopOrder> findShopOrderByUserId(int userId) {
		return shopOrderDao.findByUserId(userId);
	}



}
