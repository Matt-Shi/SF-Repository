package com.orderSystem.users.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Dish;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.entity.User;
import com.orderSystem.order.service.checkOrderService;
import com.orderSystem.order.service.cartService;
import com.orderSystem.shops.service.DishService;
import com.orderSystem.shops.service.ShopService;
import com.orderSystem.users.service.UserService;

public class OrderAction {
	private int orderId;
	private int userId;
	private int cartId;
	private int dishId;

	checkOrderService checkOrderService;
	cartService cartService;
	UserService userService;
	DishService dishService;
	ShopService shopService;

	/*=======action methods========*/
	
//	根据userId获取用户订单列表及其详细信息，用于我的订单查询
	public String getOrderByUserId() {
		List<ShopOrder> orders = checkOrderService
				.findShopOrderByUserId(userId);
		Map<Integer, List<Cart>> orderCartsMap = new HashMap<Integer, List<Cart>>();
		Map<Integer,Shop> cartShopMap = new HashMap<Integer,Shop>();
		Map<Integer,Dish> cartDishMap = new HashMap<Integer,Dish>();
		int order_i;
		List<Cart> carts = null;
		Shop shop = null;
		Dish dish = null;
		for (ShopOrder shopOrder : orders) {
			order_i = shopOrder.getOrderId();
			carts = cartService.findCartByOrderId(order_i);
			for (Cart c:carts){
				shop = shopService.findShopById(c.getShopId());
				dish = dishService.findDishById(c.getDishId());
				cartShopMap.put(c.getCartId(), shop);
				cartDishMap.put(c.getCartId(), dish);
			}
			orderCartsMap.put(order_i, carts);
		}
		User user = userService.findUserById(userId);
		ActionContext ac = ActionContext.getContext();
		ac.put("orders", orders);
		ac.put("orderCartsMap", orderCartsMap);
		ac.put("cartShopMap",cartShopMap);
		ac.put("cartDishMap", cartDishMap);
		ac.put("user", user);
		ac.put("dish", dish);
		ac.put("userId", userId);
		return "show";
	}
	
	/*=======getters and setters========*/

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getDishId() {
		return dishId;
	}

	public void setDishId(int dishId) {
		this.dishId = dishId;
	}

	public checkOrderService getCheckOrderService() {
		return checkOrderService;
	}

	public void setCheckOrderService(checkOrderService checkOrderService) {
		this.checkOrderService = checkOrderService;
	}

	public cartService getCartService() {
		return cartService;
	}

	public void setCartService(cartService cartService) {
		this.cartService = cartService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public DishService getDishService() {
		return dishService;
	}

	public void setDishService(DishService dishService) {
		this.dishService = dishService;
	}

	public ShopService getShopService() {
		return shopService;
	}

	public void setShopService(ShopService shopService) {
		this.shopService = shopService;
	}
	
	

}
