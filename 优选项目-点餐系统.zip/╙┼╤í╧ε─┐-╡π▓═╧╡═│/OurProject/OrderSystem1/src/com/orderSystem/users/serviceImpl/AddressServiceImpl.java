package com.orderSystem.users.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Transaction;

import com.orderSystem.dao.AddressDAO;
import com.orderSystem.entity.Address;
import com.orderSystem.users.service.AddressService;

/*操作地址表address的服务层接口实现类*/
public class AddressServiceImpl implements AddressService {
	
	AddressDAO addrDao = new AddressDAO();

	@SuppressWarnings("unchecked")
	@Override
	public List<Address> findAddressByUserId(int userId) {
		List<Address> addrList = new ArrayList<Address>();
		addrList = addrDao.findByUserId(userId);
		return addrList;
	}

	@Override
	public boolean updateAddress(Address addr) {
		try {
			Transaction tr = addrDao.getSession().beginTransaction();
			if (addrDao.findById(addr.getAddrId()) != null)
				addrDao.merge(addr);
			tr.commit();
			addrDao.getSession().close();
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public Address findAddressById(int addrId) {
		return addrDao.findById(addrId);
	}


	@Override
	public void deleteAddressById(int addrId) {

		Transaction tr = addrDao.getSession().beginTransaction();
		Address addr = null;
		if ((addr = addrDao.findById(addrId)) != null)
			addrDao.delete(addr);
		tr.commit();
		addrDao.getSession().close();
	}

	@Override
	public boolean saveAddress(Address addr) {
		try {
			Transaction tr = addrDao.getSession().beginTransaction();
			if (addrDao.findById(addr.getAddrId()) == null)
				addrDao.save(addr);
			tr.commit();
			addrDao.getSession().close();
		} catch (Exception e) {
			return false;
		}
		return true;
	}

}
