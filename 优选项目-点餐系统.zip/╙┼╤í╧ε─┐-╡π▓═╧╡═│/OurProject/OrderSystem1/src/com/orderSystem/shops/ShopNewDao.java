package com.orderSystem.shops;

import java.util.List;

import org.hibernate.Query;

import com.orderSystem.dao.BaseHibernateDAO;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.entity.User;

public class ShopNewDao extends BaseHibernateDAO {
	//模糊查询方法模糊查询方法模糊查询方法模糊查询方法模糊查询方法模糊查询方法模糊查询方法
	 public List findLikeByDishName(java.lang.String name,int shopId) {  
	       // log.debug("根据菜品名称模糊查询商品 " + name);  
	        try {  
	            name = "'%" + name + "%'";  
	            Query q = getSession().createQuery(  
	                    "from Dish where dishName like " + name+"and shopId="+shopId);  
//	            q.setFirstResult(beginnum);  
//	            q.setMaxResults(size);  
	            List instance = q.list();  
	            return instance;  
	        } catch (RuntimeException re) {  
	            //log.error("根据商品名称模糊查询商品出错!", re);  
	            throw re;  
	        }  
	    } 
	 public List findLikeByCartName(java.lang.String name,int shopId) {  
	       // log.debug("根据菜品名称模糊查询商品 " + name);  
	        try {  
	            name = "'%" + name + "%'";  
	            //
	            Query q = getSession().createQuery(  
	                    "select e1 from Cart e1,ShopOrder e2,User e3 where e1.orderId=e2.orderId and e2.userId=e3.userId and e3.userName like " + name+" and e1.shopId="+shopId);  
//	            q.setFirstResult(beginnum);  
//	            q.setMaxResults(size);  
	            List instance = q.list();  
	            return instance;  
	        } catch (RuntimeException re) {  
	            //log.error("根据商品名称模糊查询商品出错!", re);  
	            throw re;  
	        }  
	    }
	 public List findLikeByComplaintName(java.lang.String name,int shopId)
	 {
		 try {  
	            name = "'%" + name + "%'";  
	            //
	            Query q = getSession().createQuery(  
	                    "select e1 from Complaint e1,User e2 where e1.userId=e2.userId and e1.shopId="+shopId+" and e2.userName like " + name);  
//	            q.setFirstResult(beginnum);  
//	            q.setMaxResults(size);  
	            List instance = q.list();  
	            return instance;  
	        } catch (RuntimeException re) {  
	            //log.error("根据商品名称模糊查询商品出错!", re);  
	            throw re;  
	        }  
	 }
	 
}
