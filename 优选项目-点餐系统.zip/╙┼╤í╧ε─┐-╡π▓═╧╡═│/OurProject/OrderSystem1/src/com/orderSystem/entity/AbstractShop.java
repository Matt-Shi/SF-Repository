package com.orderSystem.entity;

/**
 * AbstractShop entity provides the base persistence definition of the Shop
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractShop implements java.io.Serializable {

	// Fields

	private Integer shopId;
	private String shopName;
	private String shopPhone;
	private String shopAddr;
	private String amOpenTime;
	private String amCloseTime;
	private String pmOpenTime;
	private String pmCloseTime;
	private String shopDesc;
	private Long account;
	private String shopPwd;
	private Integer typeId;
	private String shopImage;
	private String shopCode;

	// Constructors

	/** default constructor */
	public AbstractShop() {
	}

	/** minimal constructor */
	public AbstractShop(String shopName, String shopPwd, Integer typeId,
			String shopCode) {
		this.shopName = shopName;
		this.shopPwd = shopPwd;
		this.typeId = typeId;
		this.shopCode = shopCode;
	}

	/** full constructor */
	public AbstractShop(String shopName, String shopPhone, String shopAddr,
			String amOpenTime, String amCloseTime, String pmOpenTime,
			String pmCloseTime, String shopDesc, Long account, String shopPwd,
			Integer typeId, String shopImage, String shopCode) {
		this.shopName = shopName;
		this.shopPhone = shopPhone;
		this.shopAddr = shopAddr;
		this.amOpenTime = amOpenTime;
		this.amCloseTime = amCloseTime;
		this.pmOpenTime = pmOpenTime;
		this.pmCloseTime = pmCloseTime;
		this.shopDesc = shopDesc;
		this.account = account;
		this.shopPwd = shopPwd;
		this.typeId = typeId;
		this.shopImage = shopImage;
		this.shopCode = shopCode;
	}

	// Property accessors

	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return this.shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopPhone() {
		return this.shopPhone;
	}

	public void setShopPhone(String shopPhone) {
		this.shopPhone = shopPhone;
	}

	public String getShopAddr() {
		return this.shopAddr;
	}

	public void setShopAddr(String shopAddr) {
		this.shopAddr = shopAddr;
	}

	public String getAmOpenTime() {
		return this.amOpenTime;
	}

	public void setAmOpenTime(String amOpenTime) {
		this.amOpenTime = amOpenTime;
	}

	public String getAmCloseTime() {
		return this.amCloseTime;
	}

	public void setAmCloseTime(String amCloseTime) {
		this.amCloseTime = amCloseTime;
	}

	public String getPmOpenTime() {
		return this.pmOpenTime;
	}

	public void setPmOpenTime(String pmOpenTime) {
		this.pmOpenTime = pmOpenTime;
	}

	public String getPmCloseTime() {
		return this.pmCloseTime;
	}

	public void setPmCloseTime(String pmCloseTime) {
		this.pmCloseTime = pmCloseTime;
	}

	public String getShopDesc() {
		return this.shopDesc;
	}

	public void setShopDesc(String shopDesc) {
		this.shopDesc = shopDesc;
	}

	public Long getAccount() {
		return this.account;
	}

	public void setAccount(Long account) {
		this.account = account;
	}

	public String getShopPwd() {
		return this.shopPwd;
	}

	public void setShopPwd(String shopPwd) {
		this.shopPwd = shopPwd;
	}

	public Integer getTypeId() {
		return this.typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getShopImage() {
		return this.shopImage;
	}

	public void setShopImage(String shopImage) {
		this.shopImage = shopImage;
	}

	public String getShopCode() {
		return this.shopCode;
	}

	public void setShopCode(String shopCode) {
		this.shopCode = shopCode;
	}

}