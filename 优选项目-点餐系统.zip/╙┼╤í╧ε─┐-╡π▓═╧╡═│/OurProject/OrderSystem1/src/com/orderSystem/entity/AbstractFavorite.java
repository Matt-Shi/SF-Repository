package com.orderSystem.entity;

/**
 * AbstractFavorite entity provides the base persistence definition of the
 * Favorite entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractFavorite implements java.io.Serializable {

	// Fields

	private Integer favoriteId;
	private Integer userId;
	private Integer shopId;
	private Integer dishId;

	// Constructors

	/** default constructor */
	public AbstractFavorite() {
	}

	/** full constructor */
	public AbstractFavorite(Integer userId, Integer shopId, Integer dishId) {
		this.userId = userId;
		this.shopId = shopId;
		this.dishId = dishId;
	}

	// Property accessors

	public Integer getFavoriteId() {
		return this.favoriteId;
	}

	public void setFavoriteId(Integer favoriteId) {
		this.favoriteId = favoriteId;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public Integer getDishId() {
		return this.dishId;
	}

	public void setDishId(Integer dishId) {
		this.dishId = dishId;
	}

}