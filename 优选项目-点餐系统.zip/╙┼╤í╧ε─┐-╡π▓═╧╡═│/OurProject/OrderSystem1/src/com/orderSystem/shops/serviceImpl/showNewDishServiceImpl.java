package com.orderSystem.shops.serviceImpl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.orderSystem.dao.DishDAO;
import com.orderSystem.entity.Dish;
import com.orderSystem.shops.service.showNewDishService;

public class showNewDishServiceImpl implements showNewDishService {

	@Override
	public List<Dish> doShow() {
		// TODO Auto-generated method stub
		DishDAO dishdao = new DishDAO();
		List<Dish> newDishList = new ArrayList<Dish>();
		List<Dish> dishList = new ArrayList<Dish>();
		
		//获取当前时间
		Calendar cal = Calendar.getInstance(); 
		Calendar cal1 = Calendar.getInstance(); 
		dishList = dishdao.findAll();
		for(int j=0; j<dishList.size(); j++){
			cal1.setTime(dishList.get(j).getAddTime());
			cal1.add(Calendar.MONTH, 1);
			if(cal.compareTo(cal1) < 0)
				newDishList.add(dishList.get(j));
		}
		
		return newDishList;
	}

}
