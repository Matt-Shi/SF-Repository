package com.orderSystem.login;

import com.orderSystem.entity.Shop;

public interface checkService {
	int doCheck(String id,String pwd);
	public void add(Shop shop);
	int shopCheck(String shopCode,String shopPwd);
}
