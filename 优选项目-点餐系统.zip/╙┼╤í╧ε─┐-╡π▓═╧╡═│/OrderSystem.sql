/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50155
Source Host           : localhost:3306
Source Database       : ordersystem

Target Server Type    : MYSQL
Target Server Version : 50155
File Encoding         : 65001

Date: 2015-08-13 09:11:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `addr_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `description` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`addr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of address
-- ----------------------------

-- ----------------------------
-- Table structure for card
-- ----------------------------
DROP TABLE IF EXISTS `card`;
CREATE TABLE `card` (
  `card_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `balance` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`card_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of card
-- ----------------------------
INSERT INTO `card` VALUES ('24', '111');
INSERT INTO `card` VALUES ('25', '333');
INSERT INTO `card` VALUES ('26', '444');
INSERT INTO `card` VALUES ('27', '555');
INSERT INTO `card` VALUES ('28', '666');
INSERT INTO `card` VALUES ('30', '22');
INSERT INTO `card` VALUES ('31', '9');
INSERT INTO `card` VALUES ('32', '4567');
INSERT INTO `card` VALUES ('33', '222');
INSERT INTO `card` VALUES ('34', '444');
INSERT INTO `card` VALUES ('36', '4444');
INSERT INTO `card` VALUES ('37', '22');
INSERT INTO `card` VALUES ('39', '44444');
INSERT INTO `card` VALUES ('40', '23');
INSERT INTO `card` VALUES ('41', '455');
INSERT INTO `card` VALUES ('42', '0');
INSERT INTO `card` VALUES ('43', '2');
INSERT INTO `card` VALUES ('44', '4');
INSERT INTO `card` VALUES ('45', '44');
INSERT INTO `card` VALUES ('46', '1');
INSERT INTO `card` VALUES ('47', '333');
INSERT INTO `card` VALUES ('48', '33');
INSERT INTO `card` VALUES ('49', '44');
INSERT INTO `card` VALUES ('50', '555');
INSERT INTO `card` VALUES ('51', '66');
INSERT INTO `card` VALUES ('52', '66');

-- ----------------------------
-- Table structure for cart
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cart_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `dish_id` int(11) DEFAULT NULL,
  `dish_number` int(11) DEFAULT NULL,
  `cart_price` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO `cart` VALUES ('1', '1', '1', '1', '1', '1');
INSERT INTO `cart` VALUES ('2', '1', '2', '2', '2', '2');
INSERT INTO `cart` VALUES ('3', '1', '3', '3', '3', '3');
INSERT INTO `cart` VALUES ('4', '2', '2', '2', '2', '2');
INSERT INTO `cart` VALUES ('5', '2', '5', '5', '5', '5');
INSERT INTO `cart` VALUES ('6', '3', '3', '3', '3', '33');
INSERT INTO `cart` VALUES ('7', '3', '4', '4', '4', '44');
INSERT INTO `cart` VALUES ('8', '4', '5', '5', '5', null);
INSERT INTO `cart` VALUES ('9', null, null, null, null, null);

-- ----------------------------
-- Table structure for complaint
-- ----------------------------
DROP TABLE IF EXISTS `complaint`;
CREATE TABLE `complaint` (
  `complaint_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `descript` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of complaint
-- ----------------------------
INSERT INTO `complaint` VALUES ('1', '1', '1', '1');
INSERT INTO `complaint` VALUES ('3', '2', '2', '2');
INSERT INTO `complaint` VALUES ('4', null, null, null);
INSERT INTO `complaint` VALUES ('5', '2', '2', '222');
INSERT INTO `complaint` VALUES ('6', '1', '1', 'OK');
INSERT INTO `complaint` VALUES ('7', '1', '5', 'ffffff');
INSERT INTO `complaint` VALUES ('8', '1', '3', '可以草案');
INSERT INTO `complaint` VALUES ('9', '2', '4', '你大兄弟是谁啊？');
INSERT INTO `complaint` VALUES ('10', '2', '4', '顶顶顶顶\r\n');
INSERT INTO `complaint` VALUES ('11', '2', '3', '烦烦烦');
INSERT INTO `complaint` VALUES ('12', '2', '4', '日日日');
INSERT INTO `complaint` VALUES ('13', '1', '1', '');

-- ----------------------------
-- Table structure for dish
-- ----------------------------
DROP TABLE IF EXISTS `dish`;
CREATE TABLE `dish` (
  `dish_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dish_name` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `dish_price` decimal(10,0) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `image_url` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`dish_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of dish
-- ----------------------------

-- ----------------------------
-- Table structure for dish_type
-- ----------------------------
DROP TABLE IF EXISTS `dish_type`;
CREATE TABLE `dish_type` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of dish_type
-- ----------------------------

-- ----------------------------
-- Table structure for favorite
-- ----------------------------
DROP TABLE IF EXISTS `favorite`;
CREATE TABLE `favorite` (
  `favorite_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `dish_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`favorite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of favorite
-- ----------------------------

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `arrive_id` char(255) CHARACTER SET utf8 DEFAULT NULL,
  `order_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `total` decimal(10,0) DEFAULT NULL,
  `note` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `addr_id` int(11) DEFAULT NULL,
  `status` char(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES ('1', '1', '1', '2015-08-08 10:51:25', '1', '1', '1', '1');
INSERT INTO `order` VALUES ('2', '1', '2', '2015-08-02 10:51:47', '11', '11', '11', '1');
INSERT INTO `order` VALUES ('3', '2', '2', '2015-08-11 10:51:39', '2', '2', '2', '2');

-- ----------------------------
-- Table structure for shop
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop` (
  `shop_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `shop_image` varchar(20) DEFAULT NULL,
  `shop_code` varchar(15) NOT NULL,
  `shop_pwd` varchar(20) CHARACTER SET utf8 NOT NULL,
  `shop_phone` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `shop_addr` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `service_time` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `shop_desc` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `account` decimal(10,0) DEFAULT NULL,
  `type_id` int(11) NOT NULL,
  PRIMARY KEY (`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO `shop` VALUES ('1', '3操你大爷', null, '3', '3', '3', '3', null, '3', '0', '1');
INSERT INTO `shop` VALUES ('2', '2你妹', null, '2', '2', '2', '2', null, '2', '0', '1');
INSERT INTO `shop` VALUES ('3', '4你哥', null, '4', '4', '4', '44', null, '4', '0', '1');
INSERT INTO `shop` VALUES ('4', '2你大兄弟', null, '2', '2', '2', '2', null, '2', null, '1');
INSERT INTO `shop` VALUES ('5', '5你小妹', null, '3', '5', '5', '5', null, '5', '0', '1');
INSERT INTO `shop` VALUES ('6', '22', null, '3', '22', '22', '22', null, '22', '0', '1');
INSERT INTO `shop` VALUES ('7', '44', null, '3', '44', '44', '44', null, '44', '0', '1');
INSERT INTO `shop` VALUES ('8', '333', null, '3', '333', '3', '333', null, '3', '0', '1');
INSERT INTO `shop` VALUES ('9', '是否', null, '3', 'sfd', '是否', '是否', null, '', '0', '11');
INSERT INTO `shop` VALUES ('11', '44', null, '3', '44', '44', '44', null, '', '0', '1');
INSERT INTO `shop` VALUES ('12', '21', null, '3', '21', '21', '21', null, '212', '0', '11');
INSERT INTO `shop` VALUES ('13', '9', null, '3', '9', '9', '9', null, '9', '0', '1');
INSERT INTO `shop` VALUES ('14', '444', null, '3', '4', '4', '4', null, '', '0', '1');
INSERT INTO `shop` VALUES ('15', '67', null, '3', '67', '67', '67', null, '', '0', '1');
INSERT INTO `shop` VALUES ('16', '43', null, '3', '43', '43', '43', null, '43', '0', '11');
INSERT INTO `shop` VALUES ('17', '88', null, '88', '', '88', '88', null, '88', '0', '99');
INSERT INTO `shop` VALUES ('18', '98', null, '98', '98', '989', '88', null, '', '0', '98');
INSERT INTO `shop` VALUES ('19', '212', null, '21', '12', '', '', null, '', '0', '12');
INSERT INTO `shop` VALUES ('20', '66', null, '66', '66', '', '', null, '', '0', '66');
INSERT INTO `shop` VALUES ('21', '3333', null, '33', '33', '', '', null, '', '0', '33');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `sex` bit(1) DEFAULT NULL,
  `user_phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_icelandic_ci DEFAULT NULL,
  `card_id` int(11) DEFAULT NULL,
  `role` char(255) CHARACTER SET utf8 DEFAULT NULL,
  `pwd` varchar(16) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '1', '', '1', '11', '222', '1');
INSERT INTO `user` VALUES ('2', '光哥', '', '19999999999', '22', '333', '2');
INSERT INTO `user` VALUES ('3', '光光', '', '3', '33', '333', '3');
