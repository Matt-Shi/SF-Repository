package com.orderSystem.shops.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.entity.Dish;
import com.orderSystem.shops.service.searchDishService;
import com.orderSystem.shops.tool.searchDish;

public class searchDishServiceImpl implements searchDishService {

	@Override
	public List<Dish> doSearch(String name) {
		// TODO Auto-generated method stub
		searchDish sd = new searchDish();
		List<Dish> dishList = new ArrayList<Dish>();
		
		dishList = sd.findByNameProperty(name);
		return dishList;
	}

}
