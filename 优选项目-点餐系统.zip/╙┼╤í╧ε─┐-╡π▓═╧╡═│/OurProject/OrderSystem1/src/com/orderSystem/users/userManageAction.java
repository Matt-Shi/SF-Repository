package com.orderSystem.users;
import com.opensymphony.xwork2.ActionContext;
//import com.orderSystem.cart.cartService;
import com.orderSystem.entity.User;
//import com.orderSystem.order.orderService;
//import com.orderSystem.shops.shopService;
public class userManageAction {

	userService userSer;
	
	public userService getUserSer() {
		return userSer;
	}

	public void setUserSer(userService userSer) {
		this.userSer = userSer;
	}
	
	public String userCenter()
	{
		ActionContext actionCon=ActionContext.getContext();
		String un=(String)actionCon.getSession().get("userName");
		User user=userSer.userCenter(un);
		String sex="";
		actionCon.put("userName", user.getUserName());
		if(user.getSex()==true)
			sex="��";
		else
			sex="Ů";
		actionCon.put("userSex", sex);
		actionCon.put("userPhone", user.getUserPhone());
		actionCon.put("userRole", user.getRole());
		actionCon.put("userPwd", user.getPwd());
		actionCon.put("userCardId", user.getCardId());
		return "userCenter";
	}
	Integer orderid;
	public Integer getOrderid() {
		return orderid;
	}

	public void setOrderid(Integer orderid) {
		this.orderid = orderid;
	}
	Integer userid;

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}


	public String complaintShop()
	{
		//��һ�� ��ȡshopName
		//ͨ��orderid�ҵ����ﳵ���е�����ӵ�и�orderid��shopid
		int[] shopIds=userSer.findShopIdByOrderId(orderid);
		//ͨ��shopId��shop�����ҵ���Ӧ��shopName
		String[] shopnames=userSer.findNameByIds(shopIds);
		ActionContext actionCon=ActionContext.getContext();	
		actionCon.put("shopNames", shopnames);
		//�ڶ��� ��ȡuserName
		String username=userSer.findUserNameById(userid);
		actionCon.put("userName", username);
		return "complaintShop";
	}
}
