package com.orderSystem.administrator;

import java.util.List;

import org.hibernate.Transaction;

import com.orderSystem.dao.DishTypeDAO;
import com.orderSystem.entity.DishType;

public class dishtypeServiceImpl implements dishtypeService {

	private DishTypeDAO dishtypeDao;
	public DishTypeDAO getDishtypeDao() {
		return dishtypeDao;
	}

	public void setDishtypeDao(DishTypeDAO dishtypeDao) {
		this.dishtypeDao = dishtypeDao;
	}

	@Override
	public void save(DishType dishtype) {
		// TODO Auto-generated method stub
		Transaction ts = dishtypeDao.getSession().beginTransaction();
		dishtypeDao.save(dishtype);
		ts.commit();
		dishtypeDao.getSession().close();
	}

	@Override
	public void delete(DishType dishtype) {
		// TODO Auto-generated method stub
		if(dishtypeDao.findById(dishtype.getTypeId())!=null){
			Transaction ts = dishtypeDao.getSession().beginTransaction();
			dishtypeDao.delete(dishtype);
			ts.commit();
			dishtypeDao.getSession().close();
		}
	}

	@Override
	public DishType findDIshTypeById(int TypeId) {
		// TODO Auto-generated method stub
		return dishtypeDao.findById(TypeId);
	}

	@Override
	public List<DishType> findAll() {
		// TODO Auto-generated method stub
		return dishtypeDao.findAll();
	}

	@Override
	public void update(DishType dishtype) {
		// TODO Auto-generated method stub
		Transaction ts = dishtypeDao.getSession().beginTransaction();
		dishtypeDao.merge(dishtype);
		ts.commit();
		dishtypeDao.getSession().close();
	}

	@Override
	public List<DishType> findByTypeName(String typeName) {
		// TODO Auto-generated method stub
		
		return dishtypeDao.findByTypeName(typeName);
	}

}
