package com.orderSystem.shops.tool;

import com.orderSystem.entity.Shop;
import java.util.Calendar; 

/**
 * 工具类，用于判断商店是否在营业
 * 根据当前系统时间是否在营业时间区间之内
 * @author 855860
 *
 */
public class isOpened {
	public boolean judge(Shop shop){
		Calendar cal = Calendar.getInstance(); 
		int hour = cal.get(Calendar.HOUR_OF_DAY); 
		int minute = cal.get(Calendar.MINUTE); 
		int time = hour*100 + minute;
		if(shop.getAmOpenTime()==null)
			return true;
		//当商家处在营业时间内时，返回true类型，否则为false
		if(Integer.valueOf(shop.getAmOpenTime()) <= time && time <= Integer.valueOf(shop.getAmCloseTime()))
			return true;
		else if(Integer.valueOf(shop.getPmOpenTime()) <= time && time <= Integer.valueOf(shop.getPmCloseTime()))
			return true;
		
		return false;
	}
}
