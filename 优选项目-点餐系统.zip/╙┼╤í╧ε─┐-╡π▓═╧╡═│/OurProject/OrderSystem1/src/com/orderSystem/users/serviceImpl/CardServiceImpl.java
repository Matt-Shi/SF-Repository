package com.orderSystem.users.serviceImpl;

import com.orderSystem.dao.CardDAO;
import com.orderSystem.entity.Card;
import com.orderSystem.users.service.CardService;

/*操作储值卡表card的服务层接口实现类*/
public class CardServiceImpl implements CardService {

	CardDAO cardDao = new CardDAO();
	
	@Override
	public Card findCardById(int id) {
		return cardDao.findById(id);
	}

}
