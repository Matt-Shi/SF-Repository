package com.orderSystem.entity;

/**
 * Shop entity. @author MyEclipse Persistence Tools
 */
public class Shop extends AbstractShop implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Shop() {
	}

	/** minimal constructor */
	public Shop(String shopName, String shopCode, String shopPwd, Integer typeId) {
		super(shopName, shopCode, shopPwd, typeId);
	}

	/** full constructor */
	public Shop(String shopName, String shopImage, String shopCode,
			String shopPwd, String shopPhone, String shopAddr,
			String serviceTime, String shopDesc, long account, Integer typeId) {
		super(shopName, shopImage, shopCode, shopPwd, shopPhone, shopAddr,
				serviceTime, shopDesc, account, typeId);
	}

}
