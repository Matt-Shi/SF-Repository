package com.orderSystem.shops.service;

import java.util.List;

import com.orderSystem.entity.Shop;

public interface showShopService {
	List<Shop> doShow(String shopType);
}