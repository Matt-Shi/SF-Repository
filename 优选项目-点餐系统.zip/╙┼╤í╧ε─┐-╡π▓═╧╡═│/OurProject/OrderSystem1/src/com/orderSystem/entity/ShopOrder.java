package com.orderSystem.entity;

import java.sql.Timestamp;

/**
 * ShopOrder entity. @author MyEclipse Persistence Tools
 */
public class ShopOrder extends AbstractShopOrder implements
		java.io.Serializable {

	// Constructors

	/** default constructor */
	public ShopOrder() {
	}

	/** full constructor */
	public ShopOrder(Integer userId, Timestamp orderTime, Long total,
			Integer addrId) {
		super(userId, orderTime, total, addrId);
	}

}
