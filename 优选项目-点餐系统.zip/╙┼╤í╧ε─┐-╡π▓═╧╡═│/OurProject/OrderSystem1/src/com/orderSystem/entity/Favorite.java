package com.orderSystem.entity;

/**
 * Favorite entity. @author MyEclipse Persistence Tools
 */
public class Favorite extends AbstractFavorite implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Favorite() {
	}

	/** full constructor */
	public Favorite(Integer userId, Integer shopId, Integer dishId) {
		super(userId, shopId, dishId);
	}

}
