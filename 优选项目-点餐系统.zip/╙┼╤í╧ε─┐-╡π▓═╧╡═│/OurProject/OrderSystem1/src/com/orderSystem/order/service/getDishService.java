package com.orderSystem.order.service;

import java.util.List;

import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Dish;

public interface getDishService {
	List<Dish> getDish(List<Cart> cartList);
}
