package com.orderSystem.card;
import java.util.List;
import org.hibernate.Transaction;
import com.orderSystem.dao.CardDAO;
import com.orderSystem.entity.Card;

public class cardServiceImpl implements cardService{
	CardDAO carddao=new CardDAO();
	//�������д�ֵ��
	@Override
	public List<Card> getAllCard() {
		return carddao.findAll();
	}

	//���Ӵ�ֵ��
	@Override
	public int addCard(Card card) {
		
		// TODO Auto-generated method stub
		CardDAO carddao=new CardDAO();
		Transaction tr = carddao.getSession().beginTransaction();
//		Card c = carddao.findById(card.getCardId());
//		if (c==null)
			carddao.save(card);
//		else
//			System.out.println("��ֵ�����������⣡��");
		tr.commit();
		carddao.getSession().close();
		
		return 0;
	}

	@Override
	public int deleteCard(int cardId) {
		// TODO Auto-generated method stub	
		Transaction tr = carddao.getSession().beginTransaction();
		Card card=null;
		if ((card=carddao.findById(cardId))!= null)
			carddao.delete(card);
		tr.commit();
		carddao.getSession().close();
		return 0;
	}

	//���´�ֵ����Ϣ
	@Override
	public boolean updateCard(Card card) {
		// TODO Auto-generated method stub
			Transaction tr = carddao.getSession().beginTransaction();
			Integer cardId=card.getCardId();
			Card c=null;
			if ((c=carddao.findById(cardId))!= null)
				{
					//System.out.println("cccccccccccc");
					carddao.merge(card);
					tr.commit();
					carddao.getSession().close();
					return true;
				}		
				return false;
	}

	@Override
	public Card findByCardId(Integer cardId) {		
		Card card=carddao.findById(cardId);
		return card;
	}
	
}
