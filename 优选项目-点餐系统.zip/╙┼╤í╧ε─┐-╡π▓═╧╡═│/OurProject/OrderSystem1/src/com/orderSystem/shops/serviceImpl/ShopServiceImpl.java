package com.orderSystem.shops.serviceImpl;

import com.orderSystem.dao.ShopDAO;
import com.orderSystem.entity.Shop;
import com.orderSystem.shops.service.ShopService;

/*操作商家表shop的服务层接口实现类*/
public class ShopServiceImpl implements ShopService {

	ShopDAO shop = new ShopDAO();

	@Override
	public Shop findShopById(int id) {
		return shop.findById(id);
	}

}
