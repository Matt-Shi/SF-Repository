package com.orderSystem.administrator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

import com.orderSystem.entity.Complaint;

public class complaintAction extends ActionSupport {

	private complaintService complaintService;
	private userService userService;
	private shopService shopService;
	private int complaintId;
	private String keywords;
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public int getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}
	public userService getUserService() {
		return userService;
	}
	public void setUserService(userService userService) {
		this.userService = userService;
	}
	public shopService getShopService() {
		return shopService;
	}
	public void setShopService(shopService shopService) {
		this.shopService = shopService;
	}
	public complaintService getComplaintService() {
		return complaintService;
	}
	public void setComplaintService(complaintService complaintService) {
		this.complaintService = complaintService;
	}
	public String getUserName(int userId){
		return userService.findByUserId(userId).getUserName();
	}
	public String getShopName(int shopId){
		return shopService.findShopById(shopId).getShopName();
	}
	public String deleteOne(){
		complaintService.delete(complaintService.findComplaintById(complaintId));
		return showAll();
	}
	public List<Map<String, String>> getComplaintList(List<Complaint> comp) {
		// TODO Auto-generated method stub
		List<Map<String,String>>templist=new ArrayList<Map<String,String>>();
		Iterator<Complaint> it=comp.iterator();
		while(it.hasNext()){
			Map<String,String>map=new HashMap<String, String>();
			Complaint temp=it.next();
			int userId = temp.getUserId();
			int shopId = temp.getShopId();
			String desc = temp.getDescript();
			int compId=temp.getComplaintId();
			map.put("complaintId", Integer.toString(compId));
			map.put("userName", getUserName(userId));
			map.put("shopName", getShopName(shopId));
			map.put("desc", desc);
			templist.add(map);
		}
		return templist;
	}
	public String showAll(){
		/*List<Map<String,String>>templist=new ArrayList<Map<String,String>>();
		List<Complaint> complaintlist=complaintService.findAll();
		Iterator<Complaint> it=complaintlist.iterator();
		while(it.hasNext()){
			Map<String,String>map=new HashMap<String, String>();
			Complaint comp=it.next();
			int userId = comp.getUserId();
			int shopId = comp.getShopId();
			String desc = comp.getDescript();
			int compId=comp.getComplaintId();
			map.put("complaintId", Integer.toString(compId));
			map.put("userName", getUserName(userId));
			map.put("shopName", getShopName(shopId));
			map.put("desc", desc);
			templist.add(map);	
		}*/
		List<Complaint>complaintlist=complaintService.findAll();
		List<Map<String,String>>templist=getComplaintList(complaintlist);
		ServletActionContext.getRequest().setAttribute("templist",templist);
		return "success";
	}
	public String searchComplaint(){
		List<Complaint>complist = complaintService.findLikeByName(keywords);
		List<Map<String,String>>templist = getComplaintList(complist);
		ServletActionContext.getRequest().setAttribute("templist", templist);
		return "success";
	}
}
