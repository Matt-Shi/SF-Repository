package com.orderSystem.entity;

/**
 * User entity. @author MyEclipse Persistence Tools
 */
public class User extends AbstractUser implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public User() {
	}

	/** full constructor */
	public User(String userName, Boolean sex, String userPhone, Integer cardId,
			String role, String pwd) {
		super(userName, sex, userPhone, cardId, role, pwd);
	}
	
	

}
