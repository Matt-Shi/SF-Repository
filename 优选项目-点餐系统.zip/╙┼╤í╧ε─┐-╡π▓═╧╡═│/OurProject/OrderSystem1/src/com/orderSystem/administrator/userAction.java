package com.orderSystem.administrator;

import java.util.Iterator;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.orderSystem.entity.Complaint;
import com.orderSystem.entity.User;

public class userAction extends ActionSupport {

	private userService userService;
	private complaintService complaintService;
	private int userId;
	private String keywords;
	private User user;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public complaintService getComplaintService() {
		return complaintService;
	}
	public void setComplaintService(complaintService complaintService) {
		this.complaintService = complaintService;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public userService getUserService() {
		return userService;
	}
	public void setUserService(userService userService) {
		this.userService = userService;
	}
	public String showAll(){
		List<User>userlist=userService.findAll();
		ServletActionContext.getRequest().setAttribute("userlist",userlist);
		return "success";
	}
	public String deleteOne(){
		if(complaintService.findComplaintByUserId(userId)!=null){
			List<Complaint>complist = complaintService.findComplaintByUserId(userId);
			Iterator<Complaint>it = complist.iterator();
			while(it.hasNext()){
				Complaint comp=it.next();
				complaintService.delete(comp);
			}
		}
		userService.delete(userService.findByUserId(userId));
		return showAll();
	}
	public String searchUser(){
		List<User>userlist = userService.findLikeByName(keywords);
		ServletActionContext.getRequest().setAttribute("userlist", userlist);
		return "success";
	}
	public String userChange(){
		User user = userService.findByUserId(userId);
		ActionContext.getContext().put("user",user);
		return "success";
	}
	public String userChangeSure(){
		System.out.println(user.getSex());
		userService.updateUser(user);
		return showAll();
	}
}
