package com.orderSystem.shops.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.dao.ShopDAO;
import com.orderSystem.entity.Shop;
import com.orderSystem.shops.service.showClosedShopService;
import com.orderSystem.shops.tool.isOpened;

public class showClosedShopServiceImpl implements showClosedShopService{

	@Override
	public List<Shop> doShow(String shopType) {
		// TODO Auto-generated method stub
		ShopDAO shopdao = new ShopDAO();
		Shop shop = new Shop();
		List<Shop> closedList = new ArrayList<Shop>();
		List<Shop> shopList = new ArrayList<Shop>();
		
		isOpened io = new isOpened();//引入工具类isOpened用来判断商店是否在营业时间中
		
		shopList = shopdao.findByTypeId(Integer.valueOf(shopType));
		
		if(shopList != null){
     		for(int i=0; i<shopList.size(); i++){
	    		if(!io.judge(shopList.get(i)))
		    		closedList.add(shopList.get(i)); 
     		 }
		}
		
		if(closedList == null)
			return null;
		return closedList;
	}

}
