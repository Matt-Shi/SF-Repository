package com.orderSystem.shops.service;

import java.util.List;

import com.orderSystem.entity.Dish;

public interface searchDishService {
	List<Dish> doSearch(String name);
}
