package com.orderSystem.login;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.orderSystem.entity.Shop;


public class registerAction extends ActionSupport{
	
	checkService  checkSer;
	public checkService getCheckSer() {
		return checkSer;
	}
	public void setCheckSer(checkService checkSer) {
		this.checkSer = checkSer;
	}
	
	private Shop shop;
	public Shop getShop() {
		return shop;
	}
	public void setShop(Shop shop) {
		this.shop = shop;
	}
	
	
	int shopId;
	String shopName;
	String shopPwd;
	String shopCode;
	String pwd2;
	String shopPhone;
	String shopAddr;
	String shopDesc;
	Integer shopType;

	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopPwd() {
		return shopPwd;
	}
	public void setShopPwd(String shopPwd) {
		this.shopPwd = shopPwd;
	}
	public String getPwd2() {
		return pwd2;
	}
	public void setPwd2(String pwd2) {
		this.pwd2 = pwd2;
	}
	public String getShopPhone() {
		return shopPhone;
	}
	public void setShopPhone(String shopPhone) {
		this.shopPhone = shopPhone;
	}
	public String getShopAddr() {
		return shopAddr;
	}
	public void setShopAddr(String shopAddr) {
		this.shopAddr = shopAddr;
	}
	public String getShopDesc() {
		return shopDesc;
	}
	public void setShopDesc(String shopDesc) {
		this.shopDesc = shopDesc;
	}


	public String getShopCode() {
		return shopCode;
	}
	public void setShopCode(String shopCode) {
		this.shopCode = shopCode;
	}
	
	public Integer getShopType() {
		return shopType;
	}
	public void setShopType(Integer shopType) {
		this.shopType = shopType;
	}
	public String register(){
		Shop s=new Shop();
		//s.setShopId(shopId);
		s.setShopName(shopName);
		s.setShopCode(shopCode);
		s.setShopPwd(shopPwd);
		s.setShopAddr(shopAddr);
		s.setShopDesc(shopDesc);
		s.setShopPhone(shopPhone);
		s.setTypeId(shopType);
		System.out.println(shopPwd);
		System.out.println(pwd2);
		if(shopPwd.equals(pwd2))
		{
			checkSer.add(s);
			return "register";
		}
		else
			return "error";
		
	}
	
}
