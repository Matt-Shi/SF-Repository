package com.orderSystem.cart;
import java.util.List;
import com.orderSystem.dao.CartDAO;
import com.orderSystem.entity.Cart;
public class cartServiceImpl implements cartService {

	CartDAO cartDao=new CartDAO();
	@Override
	public int[] findShopIdByOrderId(Integer orderId) {
		// TODO Auto-generated method stub
		List<Cart> cartList=cartDao.findByOrderId(orderId);
		int[] shopIds=new int[cartList.size()];
		for(int i=0;i<cartList.size();i++)
		{
			shopIds[i]=cartList.get(i).getShopId();	
		}
		/*for(int i=0;i<shopIds.length;i++)
		{
			System.out.println(shopIds[i]);
		}*/
		
		return shopIds;
	}

}
