package com.orderSystem.shops.service;

import com.orderSystem.entity.Shop;

/*操作商家表shop的服务层接口*/
public interface ShopService {
	
	Shop findShopById(int id);//根据shopId查询其对应的商家信息
	
}
