package com.orderSystem.users.serviceImpl;


import org.hibernate.Transaction;

import com.orderSystem.dao.UserDAO;
import com.orderSystem.entity.User;
import com.orderSystem.users.service.UserService;

/*操作用户表user的服务层接口实现类*/
public class UserServiceImpl implements UserService {
	
	UserDAO userDao = new UserDAO();
	@Override
	public User findUserById(int userId) {
		return (User)userDao.findById(userId);
		
	}

	@Override
	public boolean updateUser(User user) {
		try{
			Transaction tr = userDao.getSession().beginTransaction();
			if (userDao.findById(user.getUserId()) != null)
				userDao.merge(user);
			tr.commit();
			userDao.getSession().close();
			}catch(Exception e)
		{
			return false;
		}
		return true;
	}

}
