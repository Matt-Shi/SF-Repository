package com.orderSystem.login;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.orderSystem.entity.User;


public class loginAction extends ActionSupport {

	private User user;
	private int i;
	private String userName;
	private String userPwd;
	checkService cs;
	private String yzm;
		
	public String getYzm() {
		return yzm;
	}

	public void setYzm(String yzm) {
		this.yzm = yzm;
	}
	
	 public String login(){
		//��ȡ��֤��ͼƬ�е��ַ���
		String str=(String) ActionContext.getContext().getSession().get("rand");
		//����ȡ���ַ�������֤���е�ֵ���жԱ�		
		if(str.equals(yzm))
		{
			i = cs.doCheck(userName, userPwd);
			if(i == 1)	
			{
				ActionContext actionCon=ActionContext.getContext();
				actionCon.getSession().put("userName", userName);
				return "login";
			}
			else{
				this.addFieldError("error", "*�û�����������󣡣���");
				return "error";
			}
		}
		else 
			this.addFieldError("error", "*��֤����󣡣���");
			return "error";
	}
	
/*********************getters and setters******************************/	
	public User getUser() {
		return user;
	}
	public void setUser(User  user) {
		this.user = user;
	}
	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

//	public String getUserId() {
//		return userId;
//	}
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public checkService getCs() {
		return cs;
	}
	public void setCs(checkService cs) {
		this.cs = cs;
	}
}
