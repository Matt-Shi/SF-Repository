package com.orderSystem.shops.action;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.entity.Dish;
import com.orderSystem.shops.service.showNewDishService;

public class showNewDishAction {
	private List<Dish> dishList = new ArrayList<Dish>();
	showNewDishService shownds;
	
	public String showNewDish(){
		dishList = shownds.doShow();
		return "newDishpage";
	}
	
	
/**************Getters and Setters*********************************/
	public List<Dish> getDishList() {
		return dishList;
	}
	public void setDishList(List<Dish> dishList) {
		this.dishList = dishList;
	}
	public showNewDishService getShownds() {
		return shownds;
	}
	public void setShownds(showNewDishService shownds) {
		this.shownds = shownds;
	}
}
