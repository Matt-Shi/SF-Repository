package com.orderSystem.shops.service;

import java.util.List;

import com.orderSystem.entity.Shop;

public interface showClosedShopService {
	List<Shop> doShow(String shopType);
}
