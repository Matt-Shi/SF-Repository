package com.orderSystem.entity;

/**
 * Shop entity. @author MyEclipse Persistence Tools
 */
public class Shop extends AbstractShop implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Shop() {
	}

	/** minimal constructor */
	public Shop(String shopName, String shopPwd, Integer typeId, String shopCode) {
		super(shopName, shopPwd, typeId, shopCode);
	}

	/** full constructor */
	public Shop(String shopName, String shopPhone, String shopAddr,
			String amOpenTime, String amCloseTime, String pmOpenTime,
			String pmCloseTime, String shopDesc, Long account, String shopPwd,
			Integer typeId, String shopImage, String shopCode) {
		super(shopName, shopPhone, shopAddr, amOpenTime, amCloseTime,
				pmOpenTime, pmCloseTime, shopDesc, account, shopPwd, typeId,
				shopImage, shopCode);
	}

}
