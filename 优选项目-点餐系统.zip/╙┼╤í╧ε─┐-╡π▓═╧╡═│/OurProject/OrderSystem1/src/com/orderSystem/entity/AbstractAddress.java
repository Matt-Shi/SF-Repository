package com.orderSystem.entity;

/**
 * AbstractAddress entity provides the base persistence definition of the
 * Address entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractAddress implements java.io.Serializable {

	// Fields

	private Integer addrId;
	private Integer userId;
	private String description;

	// Constructors

	/** default constructor */
	public AbstractAddress() {
	}

	/** full constructor */
	public AbstractAddress(Integer userId, String description) {
		this.userId = userId;
		this.description = description;
	}

	// Property accessors

	public Integer getAddrId() {
		return this.addrId;
	}

	public void setAddrId(Integer addrId) {
		this.addrId = addrId;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}