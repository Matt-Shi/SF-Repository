package com.orderSystem.entity;

import java.sql.Timestamp;

/**
 * Dish entity. @author MyEclipse Persistence Tools
 */
public class Dish extends AbstractDish implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Dish() {
	}

	/** full constructor */
	public Dish(String dishName, Long dishPrice, Integer shopId,
			String imageUrl, Timestamp addTime) {
		super(dishName, dishPrice, shopId, imageUrl, addTime);
	}

}
