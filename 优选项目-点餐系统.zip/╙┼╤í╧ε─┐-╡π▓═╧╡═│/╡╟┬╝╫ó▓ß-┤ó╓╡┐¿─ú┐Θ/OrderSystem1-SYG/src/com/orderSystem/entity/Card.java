package com.orderSystem.entity;

/**
 * Card entity. @author MyEclipse Persistence Tools
 */
public class Card extends AbstractCard implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Card() {
	}

	/** full constructor */
	public Card(long balance) {
		super(balance);
	}

}
