package com.orderSystem.entity;

/**
 * AbstractCard entity provides the base persistence definition of the Card
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractCard implements java.io.Serializable {

	// Fields

	private Integer cardId;
	private long balance;

	// Constructors

	/** default constructor */
	public AbstractCard() {
	}

	/** full constructor */
	public AbstractCard(long balance) {
		this.balance = balance;
	}

	// Property accessors

	public Integer getCardId() {
		return this.cardId;
	}

	public void setCardId(Integer cardId) {
		this.cardId = cardId;
	}

	public long getBalance() {
		return this.balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

}