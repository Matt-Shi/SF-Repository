package com.orderSystem.dao;

import com.orderSystem.entity.Dish;

import java.sql.Timestamp;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.criterion.Example;

/**
 * A data access object (DAO) providing persistence and search support for Dish
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.orderSystem.entity.Dish
 * @author MyEclipse Persistence Tools
 */
public class DishDAO extends BaseHibernateDAO {
	private static final Log log = LogFactory.getLog(DishDAO.class);
	// property constants
	public static final String DISH_NAME = "dishName";
	public static final String DISH_PRICE = "dishPrice";
	public static final String SHOP_ID = "shopId";
	public static final String IMAGE_URL = "imageUrl";

	public void save(Dish transientInstance) {
		log.debug("saving Dish instance");
		try {
			getSession().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Dish persistentInstance) {
		log.debug("deleting Dish instance");
		try {
			getSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Dish findById(java.lang.Integer id) {
		log.debug("getting Dish instance with id: " + id);
		try {
			Dish instance = (Dish) getSession().get(
					"com.orderSystem.entity.Dish", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Dish instance) {
		log.debug("finding Dish instance by example");
		try {
			List results = getSession()
					.createCriteria("com.orderSystem.entity.Dish")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Dish instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Dish as model where model."
					+ propertyName + "= ?";
			Query queryObject = getSession().createQuery(queryString);
			queryObject.setParameter(0, value);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByDishName(Object dishName) {
		return findByProperty(DISH_NAME, dishName);
	}

	public List findByDishPrice(Object dishPrice) {
		return findByProperty(DISH_PRICE, dishPrice);
	}

	public List findByShopId(Object shopId) {
		return findByProperty(SHOP_ID, shopId);
	}

	public List findByImageUrl(Object imageUrl) {
		return findByProperty(IMAGE_URL, imageUrl);
	}

	public List findAll() {
		log.debug("finding all Dish instances");
		try {
			String queryString = "from Dish";
			Query queryObject = getSession().createQuery(queryString);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Dish merge(Dish detachedInstance) {
		log.debug("merging Dish instance");
		try {
			Dish result = (Dish) getSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Dish instance) {
		log.debug("attaching dirty Dish instance");
		try {
			getSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Dish instance) {
		log.debug("attaching clean Dish instance");
		try {
			getSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
}