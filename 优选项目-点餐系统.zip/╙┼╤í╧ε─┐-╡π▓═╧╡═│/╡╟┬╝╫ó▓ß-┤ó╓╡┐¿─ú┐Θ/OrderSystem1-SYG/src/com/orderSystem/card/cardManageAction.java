package com.orderSystem.card;

import java.util.List;

import com.opensymphony.xwork2.ActionContext;

import com.orderSystem.entity.Card;

public class cardManageAction {
	//Action�е����к�����û�в���  ���еĲ���ͨ��get��set���úͻ�ȡ
	cardService cardSer;
	public cardService getCardSer() {
		return cardSer;
	}
	public void setCardSer(cardService cardSer) {
		this.cardSer = cardSer;
	}
	//�������д�ֵ����Ϣ
	public String findAll() {	
		ActionContext context=ActionContext.getContext();	
		List<Card> cards=cardSer.getAllCard();
		context.put("cards", cards);
		return "allcards";
	}
	
	String cardBalance;
	public String getCardBalance() {
		return cardBalance;
	}
	public void setCardBalance(String cardBalance) {
		this.cardBalance = cardBalance;
	}
	
	//���Ӵ�ֵ��
	public String addCard()
	{	
		Card card=new Card();
		if(cardBalance.isEmpty())
			return "error";
		card.setBalance(Long.parseLong(cardBalance));
		cardSer.addCard(card);
		return "allcards";		
	}

		
		Integer cardId;
		public Integer getCardId() {
		return cardId;
		}
		public void setCardId(Integer cardId) {
			this.cardId = cardId;
		}
		//ɾ����ֵ��
		public String deleteCard()
		{		
			cardSer.deleteCard(cardId);			
			return "allcards";
		}
		
		//�ύ���´�ֵ����Ϣ
		public String updateCard()
		{
			//System.out.println("dsfsdf");
			ActionContext context=ActionContext.getContext();
			Card card=cardSer.findByCardId(cardId);
			context.put("cardBalance", card.getBalance());
			context.put("cardId", card.getCardId());
			return "updateCards";
		}
		//���Ĵ�ֵ����ֵ
		public String updateCardValue(){
		//	System.out.println("daaaaa");
			Card card=new Card();
			card.setCardId(cardId);
		//	System.out.println(cardId);
			card.setBalance(Long.parseLong(cardBalance));
		//	System.out.println(cardBalance);
			cardSer.updateCard(card);
		//	System.out.println("ddddddddddd");
			return "allcards";
		}
		
}
