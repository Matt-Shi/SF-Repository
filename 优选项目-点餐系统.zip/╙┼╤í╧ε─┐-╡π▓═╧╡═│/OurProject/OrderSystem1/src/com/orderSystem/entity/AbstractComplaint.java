package com.orderSystem.entity;

/**
 * AbstractComplaint entity provides the base persistence definition of the
 * Complaint entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractComplaint implements java.io.Serializable {

	// Fields

	private Integer complaintId;
	private Integer userId;
	private Integer shopId;
	private String descript;

	// Constructors

	/** default constructor */
	public AbstractComplaint() {
	}

	/** full constructor */
	public AbstractComplaint(Integer userId, Integer shopId, String descript) {
		this.userId = userId;
		this.shopId = shopId;
		this.descript = descript;
	}

	// Property accessors

	public Integer getComplaintId() {
		return this.complaintId;
	}

	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public String getDescript() {
		return this.descript;
	}

	public void setDescript(String descript) {
		this.descript = descript;
	}

}