package com.orderSystem.shops.tool;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;

import com.orderSystem.dao.DishDAO;
import com.orderSystem.entity.Dish;

public class searchDish extends DishDAO{
	private static final Log log = LogFactory.getLog(DishDAO.class);

	public List findLikeByName(java.lang.String name) {
		// log.debug("根据菜品名称模糊查询商品 " + name);
		try {
			name = "'%" + name + "%'";
			Query q = getSession().createQuery(
					"from Dish where dishName like " + name );
			// q.setFirstResult(beginnum);
			// q.setMaxResults(size);
			List instance = q.list();
			return instance;
		} catch (RuntimeException re) {
			// log.error("根据商品名称模糊查询商品出错!", re);
			throw re;
		}
	}
	
	public List findByNameProperty(String dishName) {
		log.debug("finding Dish instance with dishName: " + dishName);
		try {
			dishName = "%" + dishName + "%";
			String queryString = "from Dish as model where model."
					+ DISH_NAME + " like ?";
			Query queryObject = getSession().createQuery(queryString);
			queryObject.setParameter(0, dishName);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}
}
