package com.orderSystem.login;

import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.Shop;


public class shoploginAction {
	private Shop shop;
	private int i;
	private String shopCode;
	private String shopPwd;
	checkService cs;
	private String yzm;
		
	
	
	 public Shop getShop() {
		return shop;
	}

	public void setShop(Shop shop) {
		this.shop = shop;
	}

	public String getShopCode() {
		return shopCode;
	}
	public void setShopCode(String shopCode) {
		this.shopCode = shopCode;
	}

	public String getShopPwd() {
		return shopPwd;
	}
	public void setShopPwd(String shopPwd) {
		this.shopPwd = shopPwd;
	}

	public String getYzm() {
		return yzm;
	}
	public void setYzm(String yzm) {
		this.yzm = yzm;
	}

	public String login(){
		//��ȡ��֤��ͼƬ�е��ַ���
		String str=(String) ActionContext.getContext().getSession().get("rand");
		//����ȡ���ַ�������֤���е�ֵ���жԱ�		
		if(str.equals(yzm))
		{
			i = cs.shopCheck(shopCode, shopPwd);
			if(i == 1)
				return "login";
			else
				return "error";
		}
		else 
			  
			return "error";
	}

	public checkService getCs() {
		return cs;
	}

	public void setCs(checkService cs) {
		this.cs = cs;
	}
}
