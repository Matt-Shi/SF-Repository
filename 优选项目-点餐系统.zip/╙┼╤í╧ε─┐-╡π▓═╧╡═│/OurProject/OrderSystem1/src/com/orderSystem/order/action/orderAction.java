package com.orderSystem.order.action;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Dish;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.order.service.getDishService;
import com.orderSystem.order.service.getPayService;
import com.orderSystem.order.service.showOrderService;

import javax.servlet.http.*;

import org.apache.struts2.ServletActionContext;

public class orderAction {
	String shopId;
	String userId;
	String description;
	int addrId;
	int orderId;
	showOrderService showos;
	getDishService getds;
	getPayService getps;
	//返回购物车信息
	List<Cart> cartList = new ArrayList<Cart>();
	//返回菜品信息
	List<Dish> dishList = new ArrayList<Dish>();
	
	private String cartPrice;
	
	//下为打开订单页面用来确定订单并且填写用户工号和送餐地址等相关的订单信息
	public String saveOrder(){
		cartList = showos.showCart(shopId);
		dishList = getds.getDish(cartList);//获取cart中对应的菜品列表
		return "orderPage";
	}
	
	//提交最终订单并付款
	public String getPay(){
		System.out.println("/*********************************8/");
		System.out.println(cartPrice);
		addrId = getps.getAddr(description);
		orderId = getps.getOrder(addrId);
		getps.getPay(userId, orderId);
		return "paySuccess";
	}
	
/******************Getters and Setters*****************************************/
	public String getShopId() {
		return shopId;
	}

	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	public showOrderService getShowos() {
		return showos;
	}

	public void setShowos(showOrderService showos) {
		this.showos = showos;
	}
	public getDishService getGetds() {
		return getds;
	}
	public void setGetds(getDishService getds) {
		this.getds = getds;
	}
	public List<Cart> getCartList() {
		return cartList;
	}
	public void setCartList(List<Cart> cartList) {
		this.cartList = cartList;
	}
	public List<Dish> getDishList() {
		return dishList;
	}
	public void setDishList(List<Dish> dishList) {
		this.dishList = dishList;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getAddrId() {
		return addrId;
	}

	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}

	public getPayService getGetps() {
		return getps;
	}

	public void setGetps(getPayService getps) {
		this.getps = getps;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getCartPrice() {
		return cartPrice;
	}

	public void setCartPrice(String cartPrice) {
		this.cartPrice = cartPrice;
	}
}
