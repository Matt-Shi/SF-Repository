package com.orderSystem.login;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.orderSystem.entity.Shop;
import com.orderSystem.shops.ShopService;


public class shoploginAction extends ActionSupport{
	private Shop shop;
	private int i;
	private String shopCode;
	private String shopPwd;
	checkService cs;
	private String yzm;
	private ShopService shopService;	
	
	
	 public Shop getShop() {
		return shop;
	}

	public void setShop(Shop shop) {
		this.shop = shop;
	}

	public String getShopCode() {
		return shopCode;
	}
	public void setShopCode(String shopCode) {
		this.shopCode = shopCode;
	}

	public String getShopPwd() {
		return shopPwd;
	}
	public void setShopPwd(String shopPwd) {
		this.shopPwd = shopPwd;
	}

	public String getYzm() {
		return yzm;
	}
	public void setYzm(String yzm) {
		this.yzm = yzm;
	}

	
	public String login(){
		Map<String,Object> session=ActionContext.getContext().getSession();
		String str=(String) session.get("rand");
		//验证码匹配
		if(str.equals(yzm))
		{
			i = cs.shopCheck(shopCode, shopPwd);
			if(i == 1)
			{
				ActionContext actionCon=ActionContext.getContext();
				session.put("sc", shopCode);
				Shop shop2=shopService.getShopByCode(shopCode);
				session.put("shopId", shop2.getShopId());
				
				ActionContext context=ActionContext.getContext();
				context.getSession().put("shopId", shop2.getShopId());
				String shoptype=shopService.getShopTypeById(shop2.getShopId());
				context.put("shop", shop2);
				context.put("shoptype", shoptype);
				String temp=shop2.getAmOpenTime();
				String amOpen=temp.substring(0, 2)+":"+temp.substring(2, 4);
				context.put("amOpen", amOpen);
				temp=shop2.getAmCloseTime();
				String amClose=temp.substring(0, 2)+":"+temp.substring(2, 4);
				context.put("amClose", amClose);
				temp=shop2.getPmOpenTime();
				String pmOpen=temp.substring(0, 2)+":"+temp.substring(2, 4);
				context.put("pmOpen", pmOpen);
				temp=shop2.getPmCloseTime();
				String pmClose=temp.substring(0, 2)+":"+temp.substring(2, 4);
				context.put("pmClose", pmClose);
				return "login";
				}
			else
			{
				this.addFieldError("error", "用户名/密码错误");
				return "error";
				}
		}
		else 
			this.addFieldError("error", "验证码错误");  
			return "error";
	}

	public checkService getCs() {
		return cs;
	}

	public void setCs(checkService cs) {
		this.cs = cs;
	}

	public ShopService getShopService() {
		return shopService;
	}

	public void setShopService(ShopService shopService) {
		this.shopService = shopService;
	}
	
}
