package com.orderSystem.shops.serviceImpl;

import com.orderSystem.dao.DishDAO;
import com.orderSystem.entity.Dish;
import com.orderSystem.shops.service.DishService;

/*操作菜品表dish的服务层接口实现类*/
public class DishServiceImpl implements DishService {

	DishDAO dishDao = new DishDAO();

	@Override
	public Dish findDishById(int id) {
		return dishDao.findById(id);
	}

}
