package com.orderSystem.administrator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.orderSystem.entity.Complaint;
import com.orderSystem.entity.DishType;
import com.orderSystem.entity.Shop;

public class shopAction extends ActionSupport {

	private shopService shopService;
	private complaintService complaintService;
	private dishtypeService dishtypeService;
	private String keywords;
	private File shopImage;
	private String shopImageFileName;
	public File getShopImage() {
		return shopImage;
	}
	public void setShopImage(File shopImage) {
		this.shopImage = shopImage;
	}
	public String getShopImageFileName() {
		return shopImageFileName;
	}
	public void setShopImageFileName(String shopImageFileName) {
		this.shopImageFileName = shopImageFileName;
	}
	private Shop shop;
	public Shop getShop() {
		return shop;
	}
	public void setShop(Shop shop) {
		this.shop = shop;
	}
	//private Map<Integer,String> typelist=new HashMap<Integer, String>();
	public dishtypeService getDishtypeService() {
		return dishtypeService;
	}
	public void setDishtypeService(dishtypeService dishtypeService) {
		this.dishtypeService = dishtypeService;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public complaintService getComplaintService() {
		return complaintService;
	}
	public void setComplaintService(complaintService complaintService) {
		this.complaintService = complaintService;
	}
	private int shopId;
	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public shopService getShopService() {
		return shopService;
	}
	public void setShopService(shopService shopService) {
		this.shopService = shopService;
	}
	public String showAll(){
		List<Map<String,String>>shoplist = new ArrayList<Map<String,String>>();
		List<Shop> templist=shopService.findAll();
		shoplist=shopService.getShopList(templist);
		ServletActionContext.getRequest().setAttribute("shoplist",shoplist);
		return "success";
	}
	
	public String deleteOne(){
		if(complaintService.findComplaintByShopId(shopId)!=null){
			List<Complaint>complist = complaintService.findComplaintByShopId(shopId);
			Iterator<Complaint>it = complist.iterator();
			while(it.hasNext()){
				Complaint comp=it.next();
				complaintService.delete(comp);
			}
		}
		shopService.delete(shopService.findShopById(shopId));
		return showAll();
	}
	public String searchShop(){
		List<Map<String,String>>shoplist = new ArrayList<Map<String,String>>();
		List<Shop>templist = shopService.findLikeByName(keywords);
		shoplist = shopService.getShopList(templist);
		ServletActionContext.getRequest().setAttribute("shoplist", shoplist);
		return "success";
	}
	public String shopChange(){
		Shop shop = shopService.findShopById(shopId);
		List<DishType>typelist = dishtypeService.findAll();
		ActionContext.getContext().put("shop",shop);
		ActionContext.getContext().put("typelist", typelist);
		return "success";
	}
	public String shopChangeSure() throws IOException{
		//shop.setShopImage(getShopImageFileName());
		if(shopImage!=null){
			String newfilename="shop/uploads/lzh"+System.currentTimeMillis()+shopImageFileName.substring(shopImageFileName.length()-5);
		InputStream is = new FileInputStream(shopImage);
		String path=((ServletContext)(ActionContext.getContext().get(ServletActionContext.SERVLET_CONTEXT))).getRealPath("/");
		File newFile = new File(path,newfilename);
		OutputStream os=new FileOutputStream(newFile);
		byte[] buffer = new byte[400];
		int length=0;
		while((length = is.read(buffer))>0)
		{
			os.write(buffer,0,length);
		}
		is.close();
		os.close();
		shop.setShopImage(newfilename);
		}
		
		shop.setAmOpenTime(shop.getAmOpenTime().replace(":", ""));
		shop.setAmCloseTime(shop.getAmCloseTime().replace(":", ""));
		shop.setPmOpenTime(shop.getPmOpenTime().replace(":", ""));
		shop.setPmCloseTime(shop.getPmCloseTime().replace(":", ""));
		shopService.updateShop(shop);
		return showAll();
	}
	public String shopReOrder(){
		List<Shop>templist=shopService.orderByShopId();
		List<Map<String,String>>shoplist = shopService.getShopList(templist);
		ServletActionContext.getRequest().setAttribute("shoplist",shoplist);
		return "success";
	}
}
