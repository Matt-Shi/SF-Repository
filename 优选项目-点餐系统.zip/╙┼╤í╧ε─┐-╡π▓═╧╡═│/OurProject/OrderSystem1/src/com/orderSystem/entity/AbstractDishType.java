package com.orderSystem.entity;

/**
 * AbstractDishType entity provides the base persistence definition of the
 * DishType entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractDishType implements java.io.Serializable {

	// Fields

	private Integer typeId;
	private String typeName;

	// Constructors

	/** default constructor */
	public AbstractDishType() {
	}

	/** full constructor */
	public AbstractDishType(String typeName) {
		this.typeName = typeName;
	}

	// Property accessors

	public Integer getTypeId() {
		return this.typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return this.typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

}