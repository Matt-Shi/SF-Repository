package com.orderSystem.order.service;

import java.util.List;

import com.orderSystem.entity.ShopOrder;

/*操作订单表shop_order的服务层接口*/
public interface checkOrderService {
	
	ShopOrder findShopOrderById(int id);// 根据orderId查询其对应的订单信息

	List<ShopOrder> findShopOrderByUserId(int userId);// 根据userId查询其对应的订单列表

}
