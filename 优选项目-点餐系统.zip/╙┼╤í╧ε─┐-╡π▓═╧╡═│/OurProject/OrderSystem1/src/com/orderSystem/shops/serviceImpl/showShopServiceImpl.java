package com.orderSystem.shops.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.dao.ShopDAO;
import com.orderSystem.entity.Shop;
import com.orderSystem.shops.service.showShopService;
import com.orderSystem.shops.tool.isOpened;

public class showShopServiceImpl implements showShopService{

	@Override
	public List<Shop> doShow(String shopType) {
		// TODO Auto-generated method stub
		ShopDAO shopdao = new ShopDAO();
		//保存所有制定类型的商家的信息
		List<Shop> shopList = new ArrayList<Shop>(); 
		//保存营业中的商家信息
		List<Shop> openList = new ArrayList<Shop>();
		int i = Integer.valueOf(shopType);
		
		isOpened is = new isOpened();
		
		//通过商店的类型找到对应的类型编号
		//由于JDK1.6不支持switch(字符串)，故使用if...else语句
		/*if(shopType.equals("中餐"))
			i = 1;
		else if(shopType.equals("西餐"))
			i = 2;
		else if(shopType.equals("甜点水果"))
			i = 3;
		else if(shopType.equals("饮品"))
			i = 4;
		else i = 5;*/
		
		shopList = shopdao.findByTypeId(i);
		if(shopList == null)
			return null;
		for(int j=0; j<shopList.size(); j++){
			if(is.judge(shopList.get(j)))
				openList.add(shopList.get(j));
		}
		return openList;
	}

}
