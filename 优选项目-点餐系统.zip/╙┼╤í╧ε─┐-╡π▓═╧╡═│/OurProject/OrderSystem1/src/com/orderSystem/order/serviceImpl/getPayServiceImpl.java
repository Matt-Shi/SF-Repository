package com.orderSystem.order.serviceImpl;

/*import java.security.Timestamp;*/
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.hibernate.Transaction;

import com.orderSystem.dao.AddressDAO;
import com.orderSystem.dao.CardDAO;
import com.orderSystem.dao.CartDAO;
import com.orderSystem.dao.ShopOrderDAO;
import com.orderSystem.dao.ShopDAO;
import com.orderSystem.dao.UserDAO;
import com.orderSystem.entity.Address;
import com.orderSystem.entity.Card;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.ShopOrder;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.User;
import com.orderSystem.order.service.getPayService;
import com.orderSystem.order.tool.getCartList;

public class getPayServiceImpl implements getPayService {

	
	//添加地址信息，返回地址表的id号
	@Override
	public int getAddr(String description) {
		// TODO Auto-generated method stub
		Address addr = new Address();
		AddressDAO adao = new AddressDAO();
		addr.setDescription(description);
		
		Transaction tr = adao.getSession().beginTransaction();
		adao.save(addr);
		tr.commit();
		adao.getSession().close();
		
		return addr.getAddrId();
	}

	//新建订单,保存订单信息，在cart表中保存订单的编号，返回订单的id
	@Override
	public int getOrder(int addrId) {
		// TODO Auto-generated method stub

		List<Integer> cartIdList = new ArrayList<Integer>();
		List<Cart> cartList = new ArrayList<Cart>();
		
        int orderId;
		ShopOrder order = new ShopOrder();
		ShopOrderDAO orderdao = new ShopOrderDAO();
		CartDAO cartdao = new CartDAO();
		//获取当前时间,并转换为timestamp类型
		Calendar cal = Calendar.getInstance();
		java.util.Date date = cal.getTime();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = df.format(date);
		Timestamp ts = Timestamp.valueOf(time);
		//保存总价格
		long total = 0;
		
		//获取当前订单对应的cart对象集合
		getCartList getcart = new getCartList();
		cartIdList = getcart.getList();
		for(int i=0; i<cartIdList.size(); i++){
			cartList.add(cartdao.findById(cartIdList.get(i)));
		}
		
		//保存订单中的地址信息、下单时间
		AddressDAO addrdao = new AddressDAO();
		order.setAddrId(addrId);
		order.setOrderTime(ts);
		Transaction tr0 = orderdao.getSession().beginTransaction();
		orderdao.save(order);
		tr0.commit();
		orderdao.getSession().close();
		
		
		orderId = order.getOrderId();
		//在cart表中保存order的id号
		for(int k=0; k<cartList.size(); k++){
			cartList.get(k).setOrderId(orderId);
			Transaction trc = cartdao.getSession().beginTransaction();
			cartdao.merge(cartList.get(k));
			trc.commit();
			cartdao.getSession().close();
			total = cartList.get(k).getCartPrice() + total;
		}
		
		//保存订单的总价格
		order.setTotal(total);
		Transaction tr1 = orderdao.getSession().beginTransaction();
		orderdao.merge(order);
		tr1.commit();
		orderdao.getSession().close();
		return order.getOrderId();
	}

	
	//用户转账给商家
	@Override
	public void getPay(String userId, int orderId) {
		// TODO Auto-generated method stub
		ShopOrderDAO orderdao = new ShopOrderDAO();
		ShopOrder order = orderdao.findById(orderId);
		Card card = new Card();
		CardDAO carddao = new CardDAO();
		User user = new User();
		UserDAO userdao = new UserDAO();
		user = userdao.findById(Integer.valueOf(userId));//获取制定用户信息
		int cardId = user.getCardId();
		List<Cart> cartList = new ArrayList<Cart>();
		CartDAO cartdao = new CartDAO();
		Shop shop = new Shop();
		ShopDAO shopdao = new ShopDAO();
		
		//在订单表中保存用户id号
		order.setUserId(Integer.valueOf(userId));
		Transaction tr2 = orderdao.getSession().beginTransaction();
		orderdao.merge(order);
		tr2.commit();
		orderdao.getSession().close();
		
		//用户账号划扣费用
		order = orderdao.findById(orderId);
		card = carddao.findById(cardId);
		if(card.getBalance() > order.getTotal())
			card.setBalance(card.getBalance() - order.getTotal());
		Transaction tr3 = carddao.getSession().beginTransaction();
		carddao.merge(card);
		tr3.commit();
		carddao.getSession().close();
		
		//转账给商家
		cartList = cartdao.findByOrderId(orderId);
		for(int kk=0; kk<cartList.size(); kk++){
			shop = shopdao.findById(cartList.get(kk).getShopId());
			shop.setAccount(shop.getAccount() + cartList.get(kk).getCartPrice());
			Transaction tr4 = shopdao.getSession().beginTransaction();
			shopdao.merge(shop);
			tr4.commit();
			shopdao.getSession().close();
		}	
	}
}
