package com.orderSystem.entity;

/**
 * AbstractShop entity provides the base persistence definition of the Shop
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractShop implements java.io.Serializable {

	// Fields

	private Integer shopId;
	private String shopName;
	private String shopImage;
	private String shopCode;
	private String shopPwd;
	private String shopPhone;
	private String shopAddr;
	private String serviceTime;
	private String shopDesc;
	private long account;
	private Integer typeId;

	// Constructors

	/** default constructor */
	public AbstractShop() {
	}

	/** minimal constructor */
	public AbstractShop(String shopName, String shopCode, String shopPwd,
			Integer typeId) {
		this.shopName = shopName;
		this.shopCode = shopCode;
		this.shopPwd = shopPwd;
		this.typeId = typeId;
	}

	/** full constructor */
	public AbstractShop(String shopName, String shopImage, String shopCode,
			String shopPwd, String shopPhone, String shopAddr,
			String serviceTime, String shopDesc, long account, Integer typeId) {
		this.shopName = shopName;
		this.shopImage = shopImage;
		this.shopCode = shopCode;
		this.shopPwd = shopPwd;
		this.shopPhone = shopPhone;
		this.shopAddr = shopAddr;
		this.serviceTime = serviceTime;
		this.shopDesc = shopDesc;
		this.account = account;
		this.typeId = typeId;
	}

	// Property accessors

	public Integer getShopId() {
		return this.shopId;
	}

	public void setShopId(Integer shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return this.shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopImage() {
		return this.shopImage;
	}

	public void setShopImage(String shopImage) {
		this.shopImage = shopImage;
	}

	public String getShopCode() {
		return this.shopCode;
	}

	public void setShopCode(String shopCode) {
		this.shopCode = shopCode;
	}

	public String getShopPwd() {
		return this.shopPwd;
	}

	public void setShopPwd(String shopPwd) {
		this.shopPwd = shopPwd;
	}

	public String getShopPhone() {
		return this.shopPhone;
	}

	public void setShopPhone(String shopPhone) {
		this.shopPhone = shopPhone;
	}

	public String getShopAddr() {
		return this.shopAddr;
	}

	public void setShopAddr(String shopAddr) {
		this.shopAddr = shopAddr;
	}

	public String getServiceTime() {
		return this.serviceTime;
	}

	public void setServiceTime(String serviceTime) {
		this.serviceTime = serviceTime;
	}

	public String getShopDesc() {
		return this.shopDesc;
	}

	public void setShopDesc(String shopDesc) {
		this.shopDesc = shopDesc;
	}

	public long getAccount() {
		return this.account;
	}

	public void setAccount(long account) {
		this.account = account;
	}

	public Integer getTypeId() {
		return this.typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

}