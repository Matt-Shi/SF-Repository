package com.orderSystem.login;

import java.io.File;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.orderSystem.entity.Shop;
import com.orderSystem.shops.ShopService;

public class registerAction extends ActionSupport {
	checkService checkSer;
	int shopId;
	String shopName;
	String shopPwd;
	String shopCode;
	String pwd2;
	String shopPhone;
	String shopAddr;
	String shopDesc;
	String shopType;
	ShopService shopService;
	public String register() {
		Shop s = new Shop();
		// s.setShopId(shopId);
		s.setShopName(shopName);
		s.setShopCode(shopCode);
		s.setShopPwd(shopPwd);
		s.setShopAddr(shopAddr);
		s.setShopDesc(shopDesc);
		s.setShopPhone(shopPhone);
		s.setAccount(0L);
		s.setAmOpenTime("0700");
		s.setAmCloseTime("1300");
		s.setPmOpenTime("1400");
		s.setPmCloseTime("1830");
		int typeId=shopService.getTypeIdByTypeName(shopType);
		s.setTypeId(typeId);
		// System.out.println(shopPwd);
		// System.out.println(pwd2);
		if (shopPwd.equals(pwd2)) {
			checkSer.add(s);
			Shop shop2=shopService.getShopByCode(shopCode);
			ActionContext context=ActionContext.getContext();
			//Map<String,Object> session=ActionContext.getContext().getSession();
			context.getSession().put("shopId", shop2.getShopId());
			
			
			context.getSession().put("shopId", shop2.getShopId());
			String shoptype=shopService.getShopTypeById(shop2.getShopId());
			context.put("shop", shop2);
			context.put("shoptype", shoptype);
			String temp=shop2.getAmOpenTime();
			String amOpen=temp.substring(0, 2)+":"+temp.substring(2, 4);
			context.put("amOpen", amOpen);
			temp=shop2.getAmCloseTime();
			String amClose=temp.substring(0, 2)+":"+temp.substring(2, 4);
			context.put("amClose", amClose);
			temp=shop2.getPmOpenTime();
			String pmOpen=temp.substring(0, 2)+":"+temp.substring(2, 4);
			context.put("pmOpen", pmOpen);
			temp=shop2.getPmCloseTime();
			String pmClose=temp.substring(0, 2)+":"+temp.substring(2, 4);
			context.put("pmClose", pmClose);
			return "register";
		} else
			return "error";
		
		
	}
	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopPwd() {
		return shopPwd;
	}

	public void setShopPwd(String shopPwd) {
		this.shopPwd = shopPwd;
	}

	public String getPwd2() {
		return pwd2;
	}

	public void setPwd2(String pwd2) {
		this.pwd2 = pwd2;
	}

	public String getShopPhone() {
		return shopPhone;
	}

	public void setShopPhone(String shopPhone) {
		this.shopPhone = shopPhone;
	}

	public String getShopAddr() {
		return shopAddr;
	}

	public void setShopAddr(String shopAddr) {
		this.shopAddr = shopAddr;
	}

	public String getShopDesc() {
		return shopDesc;
	}

	public void setShopDesc(String shopDesc) {
		this.shopDesc = shopDesc;
	}

	public String getShopCode() {
		return shopCode;
	}

	public void setShopCode(String shopCode) {
		this.shopCode = shopCode;
	}

	public String getShopType() {
		return shopType;
	}

	public void setShopType(String shopType) {
		this.shopType = shopType;
	}

	public checkService getCheckSer() {
		return checkSer;
	}

	public void setCheckSer(checkService checkSer) {
		this.checkSer = checkSer;
	}

	private Shop shop;

	public Shop getShop() {
		return shop;
	}

	public void setShop(Shop shop) {
		this.shop = shop;
	}
	public ShopService getShopService() {
		return shopService;
	}
	public void setShopService(ShopService shopService) {
		this.shopService = shopService;
	}
	

}
