package com.orderSystem.shops;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.List;
import javax.servlet.ServletContext;
import org.apache.struts2.ServletActionContext;
import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.Dish;


public class dishAction {
	private int shopId;
	private int dishId;
	private String dishName;
	private Long dishPrice;
	DishService dishService;
	private File image_url;
	private String image_urlFileName;
	private String image_urlContentType;
	private String dish_name;
	private Long dish_price;
	private File img;
	private String imgFileName;
	private String imgContentType;
	private String keywords;
	public String getAllDishByShopId()
	{
		ActionContext context=ActionContext.getContext();
		//System.out.println(shopId);
		List<Dish> dishes=dishService.getAllDishByShopId2(shopId);
		
		//System.out.println("size:"+dishes.size());
		//context.put("shopId", shopId);
		context.put("dishes", dishes);
		return "alldish";
	}
	public String deleteDishById()
	{
		dishService.deleteDishById(dishId);
		ActionContext context=ActionContext.getContext();
		List<Dish> dishes=dishService.getAllDishByShopId2(shopId);
		//context.put("shopId", shopId);
		context.put("dishes", dishes);
		return "delete";
	}

	public String addDish()
	{
		ActionContext context=ActionContext.getContext();
		//context.put("shopId", shopId);
		return "add";
	}
	//System.out.println("uploadname="+image_urlFileName);
			//SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			//String hehe=new String(dish_name.getBytes("ISO8859-1"),"UTF-8");
			//String hehe=URLDecoder.decode(dish_name, "utf-8");
	public String isAddDishSuccess() throws Exception
	{
		Dish dish=new Dish(dish_name, dish_price, shopId, image_urlFileName,new Timestamp(System.currentTimeMillis()));
		String newfilename=System.currentTimeMillis()+dish.getImageUrl().substring(dish.getImageUrl().length()-5);
		dish.setImageUrl("shop/uploads/dish2"+newfilename);
		boolean b=dishService.saveDish(dish);
		ActionContext context=ActionContext.getContext();
		context.put("b", b);
		//context.put("shopId", shopId);
			InputStream is = new FileInputStream(image_url);
			String path=((ServletContext)(ActionContext.getContext().get(ServletActionContext.SERVLET_CONTEXT))).getRealPath("/");
			System.out.println("path="+path);
			System.out.println("newname="+newfilename);
			File newFile = new File(path,dish.getImageUrl());
			OutputStream os=new FileOutputStream(newFile);
			byte[] buffer = new byte[400];
			int length=0;
			while((length = is.read(buffer))>0)
			{
				os.write(buffer,0,length);
			}
			is.close();
			os.close();
		
		return "isAddDishSuccess";
	}

	
	public String updateDish()
	{
	    Dish dish=dishService.findDishById(dishId);
		ActionContext context=ActionContext.getContext();
		context.put("dish",dish);
		//context.put("shopId", shopId);
		return"success2";
	
	}
	public String lastPage() throws Exception
	{   //修改图片
		//String img=dish.getImageUrl();//测试用的代码
		Dish dish2=dishService.findDishById(dishId);
		dish2.setDishName(dishName);
		dish2.setDishPrice(dishPrice);
		if(img!=null){
		InputStream is = new FileInputStream(img);
		String path=ServletActionContext.getServletContext().getRealPath("/");
		//Dish dish2=new Dish(dishName,dishPrice,shopId,imgFileName,new java.sql.Timestamp(System.currentTimeMillis()));
		String newfilename="shop/uploads/dish"+System.currentTimeMillis()+imgFileName.substring(imgFileName.length()-5);
		//System.out.println("path="+path);
		//System.out.println("newname="+newfilename);
		File newFile = new File(path,newfilename);
		OutputStream os=new FileOutputStream(newFile);
		byte[] buffer = new byte[400];
		int length=0;
		while((length = is.read(buffer))>0)
		{
			os.write(buffer,0,length);
		}
		is.close();
		os.close();
		dish2.setImageUrl(newfilename);
		}
	//修改价格菜名
		dishService.updateDish(dish2);
		ActionContext context=ActionContext.getContext();
		//context.put("shopId", shopId);
		List<Dish> dishes=dishService.getAllDishByShopId2(shopId);
		context.put("dishes", dishes);
		return "updatesuccess";
	}
	//按照菜名模糊查找按照菜名模糊查找按照菜名模糊查找按照菜名模糊查找按照菜名模糊查找
		public String getDishByDishName()
	    {
			  
	    	ActionContext context=ActionContext.getContext();
			//System.out.println(shopId);
			List<Dish> dishes=dishService.findByLikeName(keywords,shopId);
			//System.out.println("size:"+dishes.size());
			//context.put("shopId", shopId);
			context.put("dishes", dishes);
			return "selectdishbylikename";  //接的jsp页面只显示选择的菜品
	    }
	
	public DishService getDishService() {
		return dishService;
	}

	public void setDishService(DishService dishService) {
		this.dishService = dishService;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public int getDishId() {
		return dishId;
	}
	public void setDishId(int dishId) {
		this.dishId = dishId;
	}
	public File getImage_url() {
		return image_url;
	}
	public void setImage_url(File image_url) {
		this.image_url = image_url;
	}
	public String getDish_name() {
		return dish_name;
	}
	public void setDish_name(String dish_name) {
		this.dish_name = dish_name;
	}
	public Long getDish_price() {
		return dish_price;
	}
	public void setDish_price(Long dish_price) {
		this.dish_price = dish_price;
	}
	public String getImage_urlFileName() {
		return image_urlFileName;
	}
	public void setImage_urlFileName(String image_urlFileName) {
		this.image_urlFileName = image_urlFileName;
	}
	public String getImage_urlContentType() {
		return image_urlContentType;
	}
	public void setImage_urlContentType(String image_urlContentType) {
		this.image_urlContentType = image_urlContentType;
	}
	public String getDishName() {
		return dishName;
	}
	public void setDishName(String dishName) {
		this.dishName = dishName;
	}
	public Long getDishPrice() {
		return dishPrice;
	}
	public void setDishPrice(Long dishPrice) {
		this.dishPrice = dishPrice;
	}
	public File getImg() {
		return img;
	}
	public void setImg(File img) {
		this.img = img;
	}
	public String getImgFileName() {
		return imgFileName;
	}
	public void setImgFileName(String imgFileName) {
		this.imgFileName = imgFileName;
	}
	public String getImgContentType() {
		return imgContentType;
	}
	public void setImgContentType(String imgContentType) {
		this.imgContentType = imgContentType;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
}
