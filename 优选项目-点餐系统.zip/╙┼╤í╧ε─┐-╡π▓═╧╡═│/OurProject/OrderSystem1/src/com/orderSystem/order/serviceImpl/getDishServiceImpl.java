package com.orderSystem.order.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import com.orderSystem.dao.DishDAO;
import com.orderSystem.entity.Cart;
import com.orderSystem.entity.Dish;
import com.orderSystem.order.service.getDishService;

public class getDishServiceImpl implements getDishService {

	@Override
	public List<Dish> getDish(List<Cart> cartList) {
		// TODO Auto-generated method stub
		List<Dish> dishList = new ArrayList<Dish>();
		DishDAO dishdao = new DishDAO();
		Dish dish = new Dish();
		
		for(int i=0; i<cartList.size(); i++){
			dish = dishdao.findById(cartList.get(i).getDishId());
			dishList.add(dish);
		}
		if(dishList != null)
			return dishList;
		return null;
	}

}
