package com.orderSystem.users.action;

import java.util.*;

import com.opensymphony.xwork2.ActionContext;
import com.orderSystem.entity.Favorite;
import com.orderSystem.entity.Shop;
import com.orderSystem.entity.User;
import com.orderSystem.shops.service.ShopService;
import com.orderSystem.users.service.FavoriteService;
import com.orderSystem.users.service.UserService;

public class FavoriteAction {

	int favoriteId;
	int userId;
	int shopId;
	FavoriteService favService;
	UserService userService;
	ShopService shopService;

	/*=======action methods========*/
	
//	根据userId获取用户收藏的商家列表
	public String getFavoriteInfoByUserId() {
		List<Favorite> favs = favService.findFavoriteByUserId(userId);
		Map<Integer, Shop> favShopMap = new HashMap<Integer, Shop>();
		Shop shop = null;

		for (Favorite fav : favs) {
			shop = getShopInfoByShopId(fav.getShopId());
			favShopMap.put(fav.getFavoriteId(), shop);
		}
		User user = userService.findUserById(userId);
		ActionContext ac = ActionContext.getContext();
		ac.put("favs", favs);
		ac.put("userId", userId);
		ac.put("favShopMap", favShopMap);
		ac.put("user", user);
		return "show";
	}

//	根据shopId获取商店对象
	public Shop getShopInfoByShopId(int shopId) {
		return shopService.findShopById(shopId);
	}

//	根据收藏表favoriteId删除其对应的商家
	public String deleteFavoriteInfoById() {
		favService.deleteFavoriteById(favoriteId);
		List<Favorite> favs = favService.findFavoriteByUserId(userId);
		Map<Integer, Shop> favShopMap = new HashMap<Integer, Shop>();
		Shop shop = null;
		for (Favorite fav : favs) {
			shop = getShopInfoByShopId(fav.getShopId());
			favShopMap.put(fav.getFavoriteId(), shop);
			System.out.println(shop.getShopImage());
		}
		User user = userService.findUserById(userId);
		ActionContext ac = ActionContext.getContext();
		ac.put("favs", favs);
		ac.put("userId", userId);
		ac.put("favShopMap", favShopMap);
		ac.put("user", user);
		return "delete";
	}

	/*=======getters and setters========*/
	
	public int getFavoriteId() {
		return favoriteId;
	}

	public void setFavoriteId(int favoriteId) {
		this.favoriteId = favoriteId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public void setFavService(FavoriteService favService) {
		this.favService = favService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void setShopService(ShopService shopService) {
		this.shopService = shopService;
	}

}
