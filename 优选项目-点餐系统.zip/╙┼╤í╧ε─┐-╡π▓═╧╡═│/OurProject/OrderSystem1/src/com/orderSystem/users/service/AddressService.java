package com.orderSystem.users.service;

import java.util.List;

import com.orderSystem.entity.Address;

/*操作地址表address的服务层接口*/
public interface AddressService {

	Address findAddressById(int addrId);// 通过addrId查询其对应的地址

	List<Address> findAddressByUserId(int userId);// 通过userId查询用户所有的地址

	boolean updateAddress(Address addr);// 更新地址

	void deleteAddressById(int addrId);// 通过addrId删除其对应的地址

	boolean saveAddress(Address addr);// 保存地址信息

}
