package com.orderSystem.order.serviceImpl;

import java.util.List;

import com.orderSystem.dao.CartDAO;
import com.orderSystem.entity.Cart;
import com.orderSystem.order.service.cartService;

/*操作购物车表cart的服务层接口实现类*/
public class cartServiceImpl implements cartService {

	CartDAO cartDao = new CartDAO();

	@Override
	public Cart findCartById(int id) {
		return cartDao.findById(id);
	}

	@Override
	public List<Cart> findCartByOrderId(int orderId) {
		return cartDao.findByOrderId(orderId);
	}

}
